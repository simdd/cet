#if 0
	shc Version 4.0.1, Generic Shell Script Compiler
	GNU GPL Version 3 Md Jahidul Hamid <jahidulhamid@yahoo.com>

	shc -f cet.sh -o cet 
#endif

static  char data [] = 
#define      tst1_z	22
#define      tst1	((&data[5]))
	"\024\060\136\114\001\155\112\262\024\115\047\026\244\014\211\340"
	"\153\146\042\363\222\312\345\242\201\061\074\066\062\374\026\117"
#define      text_z	622
#define      text	((&data[123]))
	"\062\267\033\231\175\105\173\313\275\021\112\303\270\350\125\264"
	"\370\345\266\143\253\242\122\011\030\263\350\071\016\333\164\211"
	"\354\044\153\357\201\374\200\363\262\205\234\273\124\313\067\035"
	"\247\115\370\130\153\317\326\026\153\352\175\306\013\121\277\336"
	"\200\112\222\272\016\352\277\156\162\174\356\171\000\345\353\253"
	"\237\155\023\336\373\204\205\336\010\337\007\231\070\377\050\264"
	"\011\210\054\032\006\152\064\223\007\127\226\105\165\063\150\311"
	"\013\266\271\262\321\272\162\116\051\266\314\276\142\345\015\252"
	"\051\050\146\022\073\053\033\305\255\016\026\211\172\231\143\274"
	"\040\336\055\106\313\061\063\014\061\170\113\065\122\065\005\103"
	"\237\214\177\044\366\214\121\233\344\257\327\063\333\075\252\262"
	"\357\103\335\156\153\212\344\050\330\252\023\206\042\117\213\305"
	"\173\244\020\255\224\327\353\143\272\234\345\350\010\350\073\225"
	"\147\225\331\233\362\037\213\243\174\303\251\006\316\344\366\332"
	"\136\012\336\323\202\107\145\237\177\260\140\336\031\276\147\370"
	"\251\207\232\375\310\021\245\256\327\140\227\075\245\301\064\155"
	"\001\021\164\317\027\057\344\222\330\171\271\273\253\055\221\125"
	"\137\020\241\272\111\105\115\352\152\032\100\344\023\205\342\243"
	"\264\224\351\354\011\273\236\326\331\303\134\302\246\135\153\013"
	"\175\262\130\077\252\277\342\303\244\050\160\162\065\141\237\140"
	"\103\166\307\357\004\107\322\164\014\023\261\160\017\124\172\060"
	"\157\044\256\120\007\313\265\324\017\121\263\330\045\263\322\060"
	"\014\267\265\254\020\355\303\150\147\134\273\250\120\102\306\241"
	"\165\030\272\133\174\246\376\073\217\256\032\314\343\105\144\001"
	"\211\220\031\022\304\013\275\325\211\337\142\056\215\302\012\157"
	"\123\071\315\060\034\216\213\352\333\072\013\053\317\061\217\103"
	"\266\205\300\023\157\257\130\174\301\223\215\226\274\056\075\045"
	"\200\072\252\304\127\211\134\031\331\065\016\252\110\026\136\023"
	"\367\025\116\154\273\256\022\311\101\062\100\302\132\137\265\336"
	"\173\352\064\350\153\102\121\275\171\363\027\141\016\364\010\152"
	"\334\231\244\106\203\014\012\035\121\333\276\373\217\351\205\021"
	"\044\040\126\251\275\221\370\012\075\327\015\266\110\277\324\205"
	"\024\277\353\261\144\124\321\162\144\131\332\250\105\270\120\166"
	"\343\034\134\136\214\100\046\231\071\102\375\335\215\234\241\341"
	"\013\021\266\125\204\310\325\260\153\173\175\165\001\045\011\162"
	"\272\120\277\141\050\124\361\047\155\005\165\375\173\054\110\205"
	"\306\305\212\224\020\116\305\133\006\126\236\114\062\121\251\165"
	"\222\352\230\223\122\063\100\210\367\063\374\161\115\323\370\157"
	"\023\362\227\175\166\217\010\014\031\175\313\330\305\024\267\366"
	"\123\033\131\055\327\352\272\002\305\215\167\213\006\214\206\073"
	"\260\105\027\026\336\271\163\211\061\057\175\144\013\254\342\010"
	"\031\333\272\162\136\361\253\335\047\301\111\314\020\212\014\232"
	"\234\326\214\243\200\032\206\315\341\053\236\245\057\360\140\005"
	"\170\200\313\076\151\261\174\023\163\327\126\374\321\165\064\352"
	"\042\105\225\107\077\326\240\370\164\201\104\223\172\333\031\164"
	"\175\342\010\112\017\101\300\220\307\322\034\110\342\263\045\330"
	"\257\064\302\140\216\235\035\234\111\007\041\100\123\071\113\112"
	"\377\377\120\323\006\325\205\046\121\273\043\170\134\174\145\132"
	"\012\375\207\157\072\172\005\211\352\100\051\130\345\270\331\360"
	"\030\333\267\364\324\101\120\026\070\251\142\001\256\367\122\121"
	"\107\003\175\353\353\111\021\327\314\151\014\026\365\123\213\324"
	"\340\104\200\035\310\142\155\257\023\272\034"
#define      xecc_z	15
#define      xecc	((&data[862]))
	"\300\134\333\245\067\225\375\177\104\200\034\360\136\146\212\040"
	"\136\000\150\167"
#define      pswd_z	256
#define      pswd	((&data[934]))
	"\171\374\230\010\225\207\345\327\345\024\102\321\032\264\313\365"
	"\222\073\175\312\152\204\335\240\101\300\205\011\175\315\010\253"
	"\313\233\105\015\375\144\366\067\243\310\155\244\063\265\225\235"
	"\071\035\334\205\340\267\130\231\070\270\272\115\176\002\176\156"
	"\170\222\326\363\265\175\112\264\231\067\162\266\201\001\346\113"
	"\247\043\260\240\301\130\067\150\306\355\212\034\357\226\366\233"
	"\047\105\020\044\152\030\360\303\013\237\250\057\215\010\046\014"
	"\112\216\257\360\003\102\342\120\343\335\333\003\150\135\315\030"
	"\304\226\156\307\050\150\047\103\136\175\357\171\116\033\237\114"
	"\060\026\065\227\055\311\013\273\143\205\245\067\107\046\376\357"
	"\270\154\200\352\040\154\153\273\121\356\242\070\311\175\003\331"
	"\331\277\216\261\273\176\155\171\044\006\055\200\017\210\113\344"
	"\367\315\141\046\054\013\044\241\014\121\274\166\126\322\311\145"
	"\075\067\255\021\055\265\205\230\221\276\276\005\121\210\210\005"
	"\045\154\366\314\327\174\015\043\204\254\301\003\201\023\377\075"
	"\161\202\173\326\246\113\353\027\365\177\064\155\022\111\252\064"
	"\205\043\074\223\075\010\366\273\055\102\036\173\132\262\302\222"
	"\247\304\042\303\042\175\056\327\116\040\102\061\153\272\304\070"
	"\307\352\310\003\350\254\143\047\124\262\032\230\326\223\300\156"
	"\374\154\102\374\063\122\264\115\237\017\365\155\176\051\211\147"
	"\344\154\003\307\370\226\175\124\172\262\251\227"
#define      lsto_z	1
#define      lsto	((&data[1211]))
	"\153"
#define      chk1_z	22
#define      chk1	((&data[1216]))
	"\136\153\131\050\017\177\334\274\115\214\360\260\345\254\125\325"
	"\215\156\234\265\246\130\250\327\362\061"
#define      shll_z	10
#define      shll	((&data[1239]))
	"\014\150\331\312\317\035\253\040\271\046\334\066"
#define      inlo_z	3
#define      inlo	((&data[1250]))
	"\050\333\266"
#define      msg2_z	19
#define      msg2	((&data[1256]))
	"\061\335\226\326\222\014\306\317\060\236\366\235\130\363\044\362"
	"\074\132\267\006\151\231\174"
#define      rlax_z	1
#define      rlax	((&data[1276]))
	"\156"
#define      tst2_z	19
#define      tst2	((&data[1277]))
	"\107\352\322\251\350\353\322\371\143\013\134\304\214\112\250\274"
	"\364\144\337"
#define      opts_z	1
#define      opts	((&data[1296]))
	"\211"
#define      msg1_z	65
#define      msg1	((&data[1312]))
	"\266\076\073\171\037\311\032\331\245\045\030\123\142\302\146\136"
	"\217\255\353\250\317\107\105\376\025\354\174\215\335\005\127\055"
	"\363\354\203\314\375\227\101\061\023\100\375\022\073\311\125\273"
	"\360\152\163\256\350\001\335\125\213\203\123\305\326\135\255\245"
	"\213\316\020\005\163\225\343\076\356\056\377\245\332\243\123\160"
	"\361\146\176\225\027\137\235\071\324\064\056\176"
#define      chk2_z	19
#define      chk2	((&data[1393]))
	"\035\140\150\067\046\203\200\136\176\143\021\064\166\235\032\101"
	"\257\162\271\076\103\335\237"
#define      date_z	1
#define      date	((&data[1412]))
	"\056"/* End of data[] */;
#define      hide_z	4096
#define SETUID 0	/* Define as 1 to call setuid(0) at start of script */
#define DEBUGEXEC	0	/* Define as 1 to debug execvp calls */
#define TRACEABLE	1	/* Define as 1 to enable ptrace the executable */
#define HARDENING	0	/* Define as 1 to disable ptrace/dump the executable */
#define HARDENINGSP	0	/* Define as 1 to disable bash child process */
#define BUSYBOXON	0	/* Define as 1 to enable work with busybox */

/* rtc.c */

#include <sys/stat.h>
#include <sys/types.h>

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

/* 'Alleged RC4' */

static unsigned char stte[256], indx, jndx, kndx;

/*
 * Reset arc4 stte. 
 */
void stte_0(void)
{
	indx = jndx = kndx = 0;
	do {
		stte[indx] = indx;
	} while (++indx);
}

/*
 * Set key. Can be used more than once. 
 */
void key(void * str, int len)
{
	unsigned char tmp, * ptr = (unsigned char *)str;
	while (len > 0) {
		do {
			tmp = stte[indx];
			kndx += tmp;
			kndx += ptr[(int)indx % len];
			stte[indx] = stte[kndx];
			stte[kndx] = tmp;
		} while (++indx);
		ptr += 256;
		len -= 256;
	}
}

/*
 * Crypt data. 
 */
void arc4(void * str, int len)
{
	unsigned char tmp, * ptr = (unsigned char *)str;
	while (len > 0) {
		indx++;
		tmp = stte[indx];
		jndx += tmp;
		stte[indx] = stte[jndx];
		stte[jndx] = tmp;
		tmp += stte[indx];
		*ptr ^= stte[tmp];
		ptr++;
		len--;
	}
}

/* End of ARC4 */

#if HARDENING

#include <sys/ptrace.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/prctl.h>
#define PR_SET_PTRACER 0x59616d61

/* Seccomp Sandboxing Init */
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/prctl.h>
#include <sys/syscall.h>
#include <sys/socket.h>

#include <linux/filter.h>
#include <linux/seccomp.h>
#include <linux/audit.h>

#define ArchField offsetof(struct seccomp_data, arch)

#define Allow(syscall) \
    BPF_JUMP(BPF_JMP+BPF_JEQ+BPF_K, SYS_##syscall, 0, 1), \
    BPF_STMT(BPF_RET+BPF_K, SECCOMP_RET_ALLOW)

struct sock_filter filter[] = {
    /* validate arch */
    BPF_STMT(BPF_LD+BPF_W+BPF_ABS, ArchField),
    BPF_JUMP( BPF_JMP+BPF_JEQ+BPF_K, AUDIT_ARCH_X86_64, 1, 0),
    BPF_STMT(BPF_RET+BPF_K, SECCOMP_RET_KILL),

    /* load syscall */
    BPF_STMT(BPF_LD+BPF_W+BPF_ABS, offsetof(struct seccomp_data, nr)),

    /* list of allowed syscalls */
    Allow(exit_group),  /* exits a processs */
    Allow(brk),         /* for malloc(), inside libc */
    Allow(mmap),        /* also for malloc() */
    Allow(munmap),      /* for free(), inside libc */

    /* and if we don't match above, die */
    BPF_STMT(BPF_RET+BPF_K, SECCOMP_RET_KILL),
};
struct sock_fprog filterprog = {
    .len = sizeof(filter)/sizeof(filter[0]),
    .filter = filter
};

/* Seccomp Sandboxing - Set up the restricted environment */
void seccomp_hardening() {
    if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0)) {
        perror("Could not start seccomp:");
        exit(1);
    }
    if (prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &filterprog) == -1) {
        perror("Could not start seccomp:");
        exit(1);
    }
} 
/* End Seccomp Sandboxing Init */

void arc4_hardrun(void * str, int len) {
    //Decode locally
    char tmp2[len];
    memcpy(tmp2, str, len);

	unsigned char tmp, * ptr = (unsigned char *)tmp2;

    int lentmp = len;

#if HARDENINGSP
    //Start tracing to protect from dump & trace
    if (ptrace(PTRACE_TRACEME, 0, 0, 0) < 0) {
        printf("Operation not permitted\n");
        kill(getpid(), SIGKILL);
        exit(1);
    }

    //Decode Bash
    while (len > 0) {
        indx++;
        tmp = stte[indx];
        jndx += tmp;
        stte[indx] = stte[jndx];
        stte[jndx] = tmp;
        tmp += stte[indx];
        *ptr ^= stte[tmp];
        ptr++;
        len--;
    }

    //Exec bash script
    system(tmp2);

    //Empty script variable
    memcpy(tmp2, str, lentmp);

    //Sinal to detach ptrace
    ptrace(PTRACE_DETACH, 0, 0, 0);
    exit(0);

    /* Seccomp Sandboxing - Start */
    seccomp_hardening();

    exit(0);
#endif /* HARDENINGSP Exit here anyway*/

    int pid, status;
    pid = fork();

    if(pid==0) {

        //Start tracing to protect from dump & trace
        if (ptrace(PTRACE_TRACEME, 0, 0, 0) < 0) {
            printf("Operation not permitted\n");
            kill(getpid(), SIGKILL);
            _exit(1);
        }

        //Decode Bash
        while (len > 0) {
            indx++;
            tmp = stte[indx];
            jndx += tmp;
            stte[indx] = stte[jndx];
            stte[jndx] = tmp;
            tmp += stte[indx];
            *ptr ^= stte[tmp];
            ptr++;
            len--;
        }

        //Exec bash script
        system(tmp2);

        //Empty script variable
        memcpy(tmp2, str, lentmp);

        //Sinal to detach ptrace
        ptrace(PTRACE_DETACH, 0, 0, 0);
        exit(0);
    }
    else {
        wait(&status);
    }

    /* Seccomp Sandboxing - Start */
    seccomp_hardening();

    exit(0);
} 
#endif /* HARDENING */

/*
 * Key with file invariants. 
 */
int key_with_file(char * file)
{
	struct stat statf[1];
	struct stat control[1];

	if (stat(file, statf) < 0)
		return -1;

	/* Turn on stable fields */
	memset(control, 0, sizeof(control));
	control->st_ino = statf->st_ino;
	control->st_dev = statf->st_dev;
	control->st_rdev = statf->st_rdev;
	control->st_uid = statf->st_uid;
	control->st_gid = statf->st_gid;
	control->st_size = statf->st_size;
	control->st_mtime = statf->st_mtime;
	control->st_ctime = statf->st_ctime;
	key(control, sizeof(control));
	return 0;
}

#if DEBUGEXEC
void debugexec(char * sh11, int argc, char ** argv)
{
	int i;
	fprintf(stderr, "shll=%s\n", sh11 ? sh11 : "<null>");
	fprintf(stderr, "argc=%d\n", argc);
	if (!argv) {
		fprintf(stderr, "argv=<null>\n");
	} else { 
		for (i = 0; i <= argc ; i++)
			fprintf(stderr, "argv[%d]=%.60s\n", i, argv[i] ? argv[i] : "<null>");
	}
}
#endif /* DEBUGEXEC */

void rmarg(char ** argv, char * arg)
{
	for (; argv && *argv && *argv != arg; argv++);
	for (; argv && *argv; argv++)
		*argv = argv[1];
}

void chkenv_end(void);

int chkenv(int argc)
{
	char buff[512];
	unsigned long mask, m;
	int l, a, c;
	char * string;
	extern char ** environ;

	mask = (unsigned long)getpid();
	stte_0();
	 key(&chkenv, (void*)&chkenv_end - (void*)&chkenv);
	 key(&data, sizeof(data));
	 key(&mask, sizeof(mask));
	arc4(&mask, sizeof(mask));
	sprintf(buff, "x%lx", mask);
	string = getenv(buff);
#if DEBUGEXEC
	fprintf(stderr, "getenv(%s)=%s\n", buff, string ? string : "<null>");
#endif
	l = strlen(buff);
	if (!string) {
		/* 1st */
		sprintf(&buff[l], "=%lu %d", mask, argc);
		putenv(strdup(buff));
		return 0;
	}
	c = sscanf(string, "%lu %d%c", &m, &a, buff);
	if (c == 2 && m == mask) {
		/* 3rd */
		rmarg(environ, &string[-l - 1]);
		return 1 + (argc - a);
	}
	return -1;
}

void chkenv_end(void){}

#if HARDENING

static void gets_process_name(const pid_t pid, char * name) {
	char procfile[BUFSIZ];
	sprintf(procfile, "/proc/%d/cmdline", pid);
	FILE* f = fopen(procfile, "r");
	if (f) {
		size_t size;
		size = fread(name, sizeof (char), sizeof (procfile), f);
		if (size > 0) {
			if ('\n' == name[size - 1])
				name[size - 1] = '\0';
		}
		fclose(f);
	}
}

void hardening() {
    prctl(PR_SET_DUMPABLE, 0);
    prctl(PR_SET_PTRACER, -1);

    int pid = getppid();
    char name[256] = {0};
    gets_process_name(pid, name);

    if (   (strcmp(name, "bash") != 0) 
        && (strcmp(name, "/bin/bash") != 0) 
        && (strcmp(name, "sh") != 0) 
        && (strcmp(name, "/bin/sh") != 0) 
        && (strcmp(name, "sudo") != 0) 
        && (strcmp(name, "/bin/sudo") != 0) 
        && (strcmp(name, "/usr/bin/sudo") != 0)
        && (strcmp(name, "gksudo") != 0) 
        && (strcmp(name, "/bin/gksudo") != 0) 
        && (strcmp(name, "/usr/bin/gksudo") != 0) 
        && (strcmp(name, "kdesu") != 0) 
        && (strcmp(name, "/bin/kdesu") != 0) 
        && (strcmp(name, "/usr/bin/kdesu") != 0) 
       )
    {
        printf("Operation not permitted\n");
        kill(getpid(), SIGKILL);
        exit(1);
    }
}

#endif /* HARDENING */

#if !TRACEABLE

#define _LINUX_SOURCE_COMPAT
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <unistd.h>

#if !defined(PT_ATTACHEXC) /* New replacement for PT_ATTACH */
   #if !defined(PTRACE_ATTACH) && defined(PT_ATTACH)
       #define PT_ATTACHEXC	PT_ATTACH
   #elif defined(PTRACE_ATTACH)
       #define PT_ATTACHEXC PTRACE_ATTACH
   #endif
#endif

void untraceable(char * argv0)
{
	char proc[80];
	int pid, mine;

	switch(pid = fork()) {
	case  0:
		pid = getppid();
		/* For problematic SunOS ptrace */
#if defined(__FreeBSD__)
		sprintf(proc, "/proc/%d/mem", (int)pid);
#else
		sprintf(proc, "/proc/%d/as",  (int)pid);
#endif
		close(0);
		mine = !open(proc, O_RDWR|O_EXCL);
		if (!mine && errno != EBUSY)
			mine = !ptrace(PT_ATTACHEXC, pid, 0, 0);
		if (mine) {
			kill(pid, SIGCONT);
		} else {
			perror(argv0);
			kill(pid, SIGKILL);
		}
		_exit(mine);
	case -1:
		break;
	default:
		if (pid == waitpid(pid, 0, 0))
			return;
	}
	perror(argv0);
	_exit(1);
}
#endif /* !TRACEABLE */

char * xsh(int argc, char ** argv)
{
	char * scrpt;
	int ret, i, j;
	char ** varg;
	char * me = argv[0];
	if (me == NULL) { me = getenv("_"); }
	if (me == 0) { fprintf(stderr, "E: neither argv[0] nor $_ works."); exit(1); }

	ret = chkenv(argc);
	stte_0();
	 key(pswd, pswd_z);
	arc4(msg1, msg1_z);
	arc4(date, date_z);
	if (date[0] && (atoll(date)<time(NULL)))
		return msg1;
	arc4(shll, shll_z);
	arc4(inlo, inlo_z);
	arc4(xecc, xecc_z);
	arc4(lsto, lsto_z);
	arc4(tst1, tst1_z);
	 key(tst1, tst1_z);
	arc4(chk1, chk1_z);
	if ((chk1_z != tst1_z) || memcmp(tst1, chk1, tst1_z))
		return tst1;
	arc4(msg2, msg2_z);
	if (ret < 0)
		return msg2;
	varg = (char **)calloc(argc + 10, sizeof(char *));
	if (!varg)
		return 0;
	if (ret) {
		arc4(rlax, rlax_z);
		if (!rlax[0] && key_with_file(shll))
			return shll;
		arc4(opts, opts_z);
#if HARDENING
	    arc4_hardrun(text, text_z);
	    exit(0);
       /* Seccomp Sandboxing - Start */
       seccomp_hardening();
#endif
		arc4(text, text_z);
		arc4(tst2, tst2_z);
		 key(tst2, tst2_z);
		arc4(chk2, chk2_z);
		if ((chk2_z != tst2_z) || memcmp(tst2, chk2, tst2_z))
			return tst2;
		/* Prepend hide_z spaces to script text to hide it. */
		scrpt = malloc(hide_z + text_z);
		if (!scrpt)
			return 0;
		memset(scrpt, (int) ' ', hide_z);
		memcpy(&scrpt[hide_z], text, text_z);
	} else {			/* Reexecute */
		if (*xecc) {
			scrpt = malloc(512);
			if (!scrpt)
				return 0;
			sprintf(scrpt, xecc, me);
		} else {
			scrpt = me;
		}
	}
	j = 0;
#if BUSYBOXON
	varg[j++] = "busybox";
	varg[j++] = "sh";
#else
	varg[j++] = argv[0];		/* My own name at execution */
#endif
	if (ret && *opts)
		varg[j++] = opts;	/* Options on 1st line of code */
	if (*inlo)
		varg[j++] = inlo;	/* Option introducing inline code */
	varg[j++] = scrpt;		/* The script itself */
	if (*lsto)
		varg[j++] = lsto;	/* Option meaning last option */
	i = (ret > 1) ? ret : 0;	/* Args numbering correction */
	while (i < argc)
		varg[j++] = argv[i++];	/* Main run-time arguments */
	varg[j] = 0;			/* NULL terminated array */
#if DEBUGEXEC
	debugexec(shll, j, varg);
#endif
	execvp(shll, varg);
	return shll;
}

int main(int argc, char ** argv)
{
#if SETUID
   setuid(0);
#endif
#if DEBUGEXEC
	debugexec("main", argc, argv);
#endif
#if HARDENING
	hardening();
#endif
#if !TRACEABLE
	untraceable(argv[0]);
#endif
	argv[1] = xsh(argc, argv);
	fprintf(stderr, "%s%s%s: %s\n", argv[0],
		errno ? ": " : "",
		errno ? strerror(errno) : "",
		argv[1] ? argv[1] : "<null>"
	);
	return 1;
}
