#if 0
	shc Version 4.0.1, Generic Shell Script Compiler
	GNU GPL Version 3 Md Jahidul Hamid <jahidulhamid@yahoo.com>

	shc -f cet.sh -o cet 
#endif

static  char data [] = 
#define      xecc_z	15
#define      xecc	((&data[0]))
	"\122\235\101\170\317\351\032\073\367\242\366\144\344\004\201\205"
	"\244"
#define      shll_z	10
#define      shll	((&data[19]))
	"\041\001\122\251\074\156\322\373\136\005\147\333\222\264"
#define      tst1_z	22
#define      tst1	((&data[32]))
	"\316\341\356\221\242\366\256\045\137\200\153\362\131\235\321\117"
	"\212\232\163\307\256\070\151\106\342\106"
#define      lsto_z	1
#define      lsto	((&data[57]))
	"\050"
#define      chk1_z	22
#define      chk1	((&data[61]))
	"\036\102\235\312\147\161\054\053\032\302\030\054\100\201\117\162"
	"\062\044\376\034\221\033\007\160\045\061\012\110\011\210"
#define      opts_z	1
#define      opts	((&data[88]))
	"\146"
#define      msg2_z	19
#define      msg2	((&data[92]))
	"\054\135\327\376\205\263\224\242\217\257\256\271\272\361\220\362"
	"\054\131\202\171\130\042\244\257\366\003"
#define      rlax_z	1
#define      rlax	((&data[115]))
	"\201"
#define      tst2_z	19
#define      tst2	((&data[117]))
	"\011\272\103\121\024\371\102\137\222\316\001\167\304\264\250\150"
	"\125\363\277\257\007\361"
#define      inlo_z	3
#define      inlo	((&data[138]))
	"\032\114\233"
#define      text_z	1316
#define      text	((&data[440]))
	"\147\012\073\054\213\246\237\106\242\127\166\252\360\161\031\142"
	"\102\034\023\267\144\245\316\165\023\067\310\151\323\242\247\221"
	"\207\275\370\110\344\100\367\240\160\041\201\135\174\060\360\324"
	"\155\004\314\205\266\002\372\355\266\064\143\017\067\344\177\266"
	"\173\035\061\175\363\116\333\014\133\105\325\050\023\336\143\201"
	"\251\003\126\354\372\066\335\221\155\244\301\017\205\056\056\347"
	"\327\045\120\256\341\271\233\101\323\051\206\036\372\271\264\176"
	"\175\152\202\201\073\233\253\345\265\025\053\142\052\354\176\026"
	"\060\030\115\123\172\042\161\340\062\343\066\016\221\161\110\235"
	"\052\365\242\077\031\343\145\026\041\215\201\341\117\107\223\226"
	"\011\127\174\217\037\323\003\302\376\354\275\030\276\007\345\056"
	"\171\010\030\223\116\164\150\344\044\067\332\353\372\345\337\235"
	"\240\164\146\171\027\340\074\175\220\324\264\141\311\134\337\023"
	"\155\134\202\115\054\231\277\003\325\006\310\357\160\346\363\107"
	"\161\331\133\351\313\016\345\053\237\063\365\175\250\354\371\043"
	"\013\174\250\271\074\223\374\130\332\042\041\223\343\370\152\113"
	"\135\237\016\273\207\104\370\126\123\056\143\112\102\342\241\064"
	"\001\352\142\266\307\315\323\254\154\303\064\053\355\356\110\142"
	"\036\266\076\222\201\323\253\045\355\071\253\033\033\300\016\020"
	"\156\366\012\050\213\136\006\107\007\243\170\070\253\257\106\213"
	"\066\163\061\244\006\004\010\075\042\104\103\274\111\162\377\260"
	"\313\134\333\050\174\306\120\200\333\357\130\215\173\147\251\260"
	"\222\116\374\314\255\341\347\167\370\363\157\156\073\133\341\311"
	"\220\002\354\062\133\237\127\117\222\005\331\143\040\223\234\150"
	"\016\310\275\041\101\021\345\116\040\123\226\052\367\012\172\047"
	"\060\340\141\071\153\256\226\156\006\177\130\034\046\247\337\147"
	"\310\146\064\325\260\222\032\263\237\162\161\264\264\173\131\235"
	"\241\066\353\365\100\063\213\143\070\251\201\015\132\024\034\061"
	"\324\172\324\253\312\344\155\166\361\305\247\241\170\107\311\231"
	"\251\036\031\354\073\012\077\306\046\143\004\203\104\122\111\010"
	"\265\220\326\203\370\352\277\324\156\324\062\134\335\101\162\275"
	"\141\266\103\055\213\045\103\143\301\244\053\276\342\374\147\260"
	"\372\364\310\255\363\317\316\237\157\055\061\336\233\050\342\240"
	"\241\013\352\144\175\366\054\024\120\216\200\167\177\374\034\244"
	"\072\245\033\163\154\351\363\032\273\254\321\333\146\273\267\237"
	"\266\351\015\212\205\254\355\107\066\046\220\143\064\121\071\276"
	"\372\166\323\375\163\353\252\150\301\045\040\160\342\314\377\074"
	"\060\264\332\155\042\262\137\054\244\062\320\050\145\030\211\347"
	"\345\221\257\254\141\346\277\266\320\260\171\140\115\150\034\303"
	"\054\366\115\067\001\136\300\031\240\123\310\160\215\212\100\135"
	"\112\023\014\032\347\164\341\022\217\120\246\002\063\205\211\143"
	"\203\246\103\162\333\007\375\205\247\124\303\101\020\364\265\217"
	"\050\142\174\241\136\226\174\017\123\214\247\035\333\342\110\156"
	"\376\222\041\264\114\076\203\164\074\050\073\223\224\135\170\377"
	"\003\126\062\147\063\240\275\352\316\301\327\160\006\056\015\176"
	"\157\231\101\175\111\261\142\106\221\142\242\236\020\353\210\270"
	"\165\350\247\223\262\335\173\163\156\167\337\204\375\237\125\341"
	"\134\300\357\170\323\266\216\365\005\017\037\042\341\220\135\101"
	"\331\377\354\144\346\351\321\255\036\146\153\333\150\121\225\171"
	"\177\127\353\174\133\333\216\042\042\330\252\212\232\272\360\342"
	"\230\156\065\165\233\276\101\025\064\003\115\133\046\066\036\203"
	"\275\235\313\000\153\201\362\312\332\274\233\362\326\133\322\100"
	"\241\253\236\117\132\040\050\112\121\174\343\177\006\211\242\152"
	"\027\375\265\055\343\025\322\053\130\373\140\221\344\035\363\117"
	"\177\173\271\002\041\226\034\113\244\261\350\346\020\363\361\231"
	"\210\046\243\117\341\207\326\202\377\312\145\077\010\336\365\051"
	"\057\371\161\077\202\053\045\321\101\241\360\326\145\262\346\326"
	"\354\145\262\136\016\252\117\026\017\300\260\323\325\104\356\220"
	"\225\303\205\364\276\317\272\015\205\163\130\337\134\113\004\333"
	"\323\220\034\002\135\372\007\110\143\227\102\131\106\205\327\347"
	"\173\256\233\116\246\302\020\151\014\345\262\273\307\064\077\057"
	"\161\006\065\310\175\173\316\274\305\261\373\132\215\252\100\177"
	"\361\231\212\235\213\140\234\373\027\305\126\037\342\233\250\370"
	"\213\071\043\044\200\220\113\015\056\253\107\272\001\354\110\072"
	"\135\126\056\167\022\056\070\064\105\216\316\253\143\226\044\015"
	"\376\370\373\125\210\130\046\326\206\264\171\102\124\317\135\206"
	"\071\375\276\151\376\135\252\342\206\157\372\224\277\256\371\137"
	"\101\344\064\311\053\021\047\336\113\164\235\044\362\234\356\070"
	"\071\162\005\130\004\275\144\224\273\234\164\337\175\227\102\210"
	"\145\216\334\353\336\265\216\365\357\021\325\056\375\130\050\226"
	"\173\102\323\073\073\231\073\107\102\117\270\000\045\217\330\067"
	"\277\076\137\163\221\023\114\363\340\247\135\006\343\234\012\024"
	"\240\135\237\235\024\374\336\170\244\153\360\057\313\062\145\352"
	"\015\246\245\241\074\021\343\135\027\123\203\327\023\307\310\176"
	"\257\244\111\167\247\102\211\211\070\240\240\255\362\031\053\174"
	"\235\142\362\241\137\243\337\240\200\156\013\357\041\254\005\244"
	"\227\263\273\273\002\153\351\067\274\300\123\216\305\225\036\132"
	"\366\063\200\202\166\105\226\210\200\065\207\221\242\206\030\205"
	"\012\015\365\305\316\054\254\273\045\125\311\371\300\354\255\044"
	"\342\103\315\000\326\132\204\334\145\362\036\075\306\324\016\201"
	"\374\224\277\101\123\146\263\057\333\361\346\245\254\260\231\141"
	"\115\363\334\270\313\325\104\217\122\124\224\025\214\012\130\127"
	"\365\044\246\340\351\015\053\375\177\357\330\274\314\075\155\370"
	"\241\352\303\341\141\250\116\341\165\325\111\267\304\204\166\342"
	"\111\205\304\341\025\236\175\254\166\003\232\041\031\264\304\047"
	"\173\050\303\064\077\126\044\254\072\224\303\242\015\206\101\010"
	"\013\040\300\137\316\244\101\031\276\352\267\350\027\225\060\352"
	"\037\200\173\116\204\220\011\012\015\115\146\223\350\251\143\065"
	"\264\020\173\176\226\166\376\306\267\116\016\307\012\200\371\136"
	"\106\307\361\305\266\224\362\217\052\241\101\326\130\320\353\307"
	"\202\105\251\376\333\132\375\053\037\136\160\027\040\012\244\121"
	"\254\020\365\157\332\243\272\124\053\241\271\107\151\305\105\224"
	"\137\161\136\330\332\340\110\310\364\203\336\333\011\136\055\131"
	"\377\202\134\206\272\055\035\247\277\333\327\017\232\000\231\203"
	"\345\217\242\341\032\133\331\025\054\005\023\252\010\214\166\263"
	"\316\304\336\237\356\142\377\154\117\226\063\371\141\016\123\346"
	"\201\333\310\042\360\151\343\322\337\351\006\301\376\134\332\156"
	"\333\260\011\074\047\362\357\223\217\151\151\142\127\245\106\317"
	"\330\244\041\327\312\226\247\350\344\252\377\313\204\277\324\206"
	"\173\216\347\120\036\014\056\320\145\321\010\146\132\120\222\321"
	"\060\304\245\115\340\004\021\131\262\265\244\376\271\263\307\231"
	"\336\352\243\100\146\151\230\252\277\135\024\154\030\113\346\246"
	"\034\330\352\152\205\227\277\335\234\175\201\337\026\240\335\264"
	"\314\000\021\324\027\237\215\064\271\207\372\152\220\016\022\045"
	"\111\250\255\211\272\155\342\271\276\162\200\205\253\316\006\337"
	"\117\314\274\300\157\156\333\157\114\104\272\072\062\250\212\117"
	"\055\010\156\220\204\262\041\265\157\070\107\072\344\107\334\310"
	"\323\317\137\225\045\264\044\171\000\346\144\240\220\372\300\241"
	"\003\015\250\246\376\076\043\126\170\233\105\206\126\266\112\216"
	"\347\062\355\244\141\256\134\122\271\055\242\155\334\131\052\326"
	"\056\146\366\255\327\235\340\166\131\360\354\111\250\043\045\176"
	"\372\314\057\103\224\354\131\371\314\372\151\004\140\044\123\150"
	"\232\072\116\277\044\010\167\362\066\364\277\350\375\317\244\354"
	"\220\100\000\111\245\337\142\027\166\112\351\157\256\055\300\130"
	"\371\167\157\232\364\272\341\354\306\264\207\123\311\360\147\032"
	"\057\063\364\017\057\115\041\337\245\012\222\204\062\260\362\210"
	"\100\075\350\331\135\063\111\206\053\373\022\121\276\073\004\213"
	"\351\035\223\174\332\077\160\142\206\305\025\261"
#define      date_z	1
#define      date	((&data[2025]))
	"\225"
#define      chk2_z	19
#define      chk2	((&data[2030]))
	"\010\074\010\324\363\126\033\366\116\240\357\206\017\344\237\115"
	"\057\251\252\276\010\136\316\363\015\165\076"
#define      pswd_z	256
#define      pswd	((&data[2061]))
	"\331\354\261\074\031\044\064\333\042\206\337\333\324\304\154\031"
	"\255\006\202\232\331\254\212\066\205\065\070\115\070\041\104\056"
	"\011\106\027\130\016\151\130\021\104\005\166\146\201\137\047\254"
	"\007\356\061\300\370\211\216\040\360\033\205\020\161\224\256\263"
	"\274\247\046\164\301\026\172\353\021\310\066\066\044\211\153\261"
	"\170\336\301\210\015\106\116\311\376\325\023\030\146\051\160\175"
	"\022\307\341\151\301\044\310\017\025\145\273\214\105\302\051\071"
	"\154\212\067\064\373\102\055\156\127\227\164\367\372\314\172\017"
	"\341\376\270\325\065\352\026\142\015\241\003\027\216\017\105\073"
	"\234\235\045\206\043\073\356\104\076\325\250\241\072\053\147\116"
	"\215\370\042\264\002\321\163\042\045\266\310\126\165\210\324\261"
	"\031\034\276\307\025\207\065\311\324\022\164\127\311\232\340\111"
	"\322\347\023\153\066\120\166\143\124\163\001\056\371\127\310\051"
	"\164\362\165\013\266\267\162\246\073\105\250\101\236\357\156\305"
	"\242\122\054\047\334\161\170\330\151\220\244\206\005\353\113\255"
	"\204\342\354\126\362\377\022\202\145\366\263\125\347\065\353\117"
	"\053\353\111\236\300\034\112\212\003\351\023\047\127\120\342\305"
	"\041\126\123\365\341\302\243\311\154\330\113\150\233\063\254\352"
	"\252\370\055\044\341\267\227\176\225\237\044\247\157\025\135\353"
	"\315\152\037\342\112\224\035\231\067\123"
#define      msg1_z	65
#define      msg1	((&data[2381]))
	"\155\022\323\106\043\272\263\060\111\154\306\162\127\175\172\367"
	"\311\225\002\066\276\155\323\364\200\010\102\152\027\213\141\346"
	"\210\052\110\200\221\150\123\355\251\164\227\173\165\336\256\113"
	"\262\142\266\074\045\013\370\313\016\245\347\342\332\000\335\200"
	"\104\246\302\344\357\126\007\246\150\044\311\103\016\332\033\115"/* End of data[] */;
#define      hide_z	4096
#define SETUID 0	/* Define as 1 to call setuid(0) at start of script */
#define DEBUGEXEC	0	/* Define as 1 to debug execvp calls */
#define TRACEABLE	1	/* Define as 1 to enable ptrace the executable */
#define HARDENING	0	/* Define as 1 to disable ptrace/dump the executable */
#define HARDENINGSP	0	/* Define as 1 to disable bash child process */
#define BUSYBOXON	0	/* Define as 1 to enable work with busybox */

/* rtc.c */

#include <sys/stat.h>
#include <sys/types.h>

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

/* 'Alleged RC4' */

static unsigned char stte[256], indx, jndx, kndx;

/*
 * Reset arc4 stte. 
 */
void stte_0(void)
{
	indx = jndx = kndx = 0;
	do {
		stte[indx] = indx;
	} while (++indx);
}

/*
 * Set key. Can be used more than once. 
 */
void key(void * str, int len)
{
	unsigned char tmp, * ptr = (unsigned char *)str;
	while (len > 0) {
		do {
			tmp = stte[indx];
			kndx += tmp;
			kndx += ptr[(int)indx % len];
			stte[indx] = stte[kndx];
			stte[kndx] = tmp;
		} while (++indx);
		ptr += 256;
		len -= 256;
	}
}

/*
 * Crypt data. 
 */
void arc4(void * str, int len)
{
	unsigned char tmp, * ptr = (unsigned char *)str;
	while (len > 0) {
		indx++;
		tmp = stte[indx];
		jndx += tmp;
		stte[indx] = stte[jndx];
		stte[jndx] = tmp;
		tmp += stte[indx];
		*ptr ^= stte[tmp];
		ptr++;
		len--;
	}
}

/* End of ARC4 */

#if HARDENING

#include <sys/ptrace.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/prctl.h>
#define PR_SET_PTRACER 0x59616d61

/* Seccomp Sandboxing Init */
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/prctl.h>
#include <sys/syscall.h>
#include <sys/socket.h>

#include <linux/filter.h>
#include <linux/seccomp.h>
#include <linux/audit.h>

#define ArchField offsetof(struct seccomp_data, arch)

#define Allow(syscall) \
    BPF_JUMP(BPF_JMP+BPF_JEQ+BPF_K, SYS_##syscall, 0, 1), \
    BPF_STMT(BPF_RET+BPF_K, SECCOMP_RET_ALLOW)

struct sock_filter filter[] = {
    /* validate arch */
    BPF_STMT(BPF_LD+BPF_W+BPF_ABS, ArchField),
    BPF_JUMP( BPF_JMP+BPF_JEQ+BPF_K, AUDIT_ARCH_X86_64, 1, 0),
    BPF_STMT(BPF_RET+BPF_K, SECCOMP_RET_KILL),

    /* load syscall */
    BPF_STMT(BPF_LD+BPF_W+BPF_ABS, offsetof(struct seccomp_data, nr)),

    /* list of allowed syscalls */
    Allow(exit_group),  /* exits a processs */
    Allow(brk),         /* for malloc(), inside libc */
    Allow(mmap),        /* also for malloc() */
    Allow(munmap),      /* for free(), inside libc */

    /* and if we don't match above, die */
    BPF_STMT(BPF_RET+BPF_K, SECCOMP_RET_KILL),
};
struct sock_fprog filterprog = {
    .len = sizeof(filter)/sizeof(filter[0]),
    .filter = filter
};

/* Seccomp Sandboxing - Set up the restricted environment */
void seccomp_hardening() {
    if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0)) {
        perror("Could not start seccomp:");
        exit(1);
    }
    if (prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &filterprog) == -1) {
        perror("Could not start seccomp:");
        exit(1);
    }
} 
/* End Seccomp Sandboxing Init */

void arc4_hardrun(void * str, int len) {
    //Decode locally
    char tmp2[len];
    memcpy(tmp2, str, len);

	unsigned char tmp, * ptr = (unsigned char *)tmp2;

    int lentmp = len;

#if HARDENINGSP
    //Start tracing to protect from dump & trace
    if (ptrace(PTRACE_TRACEME, 0, 0, 0) < 0) {
        printf("Operation not permitted\n");
        kill(getpid(), SIGKILL);
        exit(1);
    }

    //Decode Bash
    while (len > 0) {
        indx++;
        tmp = stte[indx];
        jndx += tmp;
        stte[indx] = stte[jndx];
        stte[jndx] = tmp;
        tmp += stte[indx];
        *ptr ^= stte[tmp];
        ptr++;
        len--;
    }

    //Exec bash script
    system(tmp2);

    //Empty script variable
    memcpy(tmp2, str, lentmp);

    //Sinal to detach ptrace
    ptrace(PTRACE_DETACH, 0, 0, 0);
    exit(0);

    /* Seccomp Sandboxing - Start */
    seccomp_hardening();

    exit(0);
#endif /* HARDENINGSP Exit here anyway*/

    int pid, status;
    pid = fork();

    if(pid==0) {

        //Start tracing to protect from dump & trace
        if (ptrace(PTRACE_TRACEME, 0, 0, 0) < 0) {
            printf("Operation not permitted\n");
            kill(getpid(), SIGKILL);
            _exit(1);
        }

        //Decode Bash
        while (len > 0) {
            indx++;
            tmp = stte[indx];
            jndx += tmp;
            stte[indx] = stte[jndx];
            stte[jndx] = tmp;
            tmp += stte[indx];
            *ptr ^= stte[tmp];
            ptr++;
            len--;
        }

        //Exec bash script
        system(tmp2);

        //Empty script variable
        memcpy(tmp2, str, lentmp);

        //Sinal to detach ptrace
        ptrace(PTRACE_DETACH, 0, 0, 0);
        exit(0);
    }
    else {
        wait(&status);
    }

    /* Seccomp Sandboxing - Start */
    seccomp_hardening();

    exit(0);
} 
#endif /* HARDENING */

/*
 * Key with file invariants. 
 */
int key_with_file(char * file)
{
	struct stat statf[1];
	struct stat control[1];

	if (stat(file, statf) < 0)
		return -1;

	/* Turn on stable fields */
	memset(control, 0, sizeof(control));
	control->st_ino = statf->st_ino;
	control->st_dev = statf->st_dev;
	control->st_rdev = statf->st_rdev;
	control->st_uid = statf->st_uid;
	control->st_gid = statf->st_gid;
	control->st_size = statf->st_size;
	control->st_mtime = statf->st_mtime;
	control->st_ctime = statf->st_ctime;
	key(control, sizeof(control));
	return 0;
}

#if DEBUGEXEC
void debugexec(char * sh11, int argc, char ** argv)
{
	int i;
	fprintf(stderr, "shll=%s\n", sh11 ? sh11 : "<null>");
	fprintf(stderr, "argc=%d\n", argc);
	if (!argv) {
		fprintf(stderr, "argv=<null>\n");
	} else { 
		for (i = 0; i <= argc ; i++)
			fprintf(stderr, "argv[%d]=%.60s\n", i, argv[i] ? argv[i] : "<null>");
	}
}
#endif /* DEBUGEXEC */

void rmarg(char ** argv, char * arg)
{
	for (; argv && *argv && *argv != arg; argv++);
	for (; argv && *argv; argv++)
		*argv = argv[1];
}

void chkenv_end(void);

int chkenv(int argc)
{
	char buff[512];
	unsigned long mask, m;
	int l, a, c;
	char * string;
	extern char ** environ;

	mask = (unsigned long)getpid();
	stte_0();
	 key(&chkenv, (void*)&chkenv_end - (void*)&chkenv);
	 key(&data, sizeof(data));
	 key(&mask, sizeof(mask));
	arc4(&mask, sizeof(mask));
	sprintf(buff, "x%lx", mask);
	string = getenv(buff);
#if DEBUGEXEC
	fprintf(stderr, "getenv(%s)=%s\n", buff, string ? string : "<null>");
#endif
	l = strlen(buff);
	if (!string) {
		/* 1st */
		sprintf(&buff[l], "=%lu %d", mask, argc);
		putenv(strdup(buff));
		return 0;
	}
	c = sscanf(string, "%lu %d%c", &m, &a, buff);
	if (c == 2 && m == mask) {
		/* 3rd */
		rmarg(environ, &string[-l - 1]);
		return 1 + (argc - a);
	}
	return -1;
}

void chkenv_end(void){}

#if HARDENING

static void gets_process_name(const pid_t pid, char * name) {
	char procfile[BUFSIZ];
	sprintf(procfile, "/proc/%d/cmdline", pid);
	FILE* f = fopen(procfile, "r");
	if (f) {
		size_t size;
		size = fread(name, sizeof (char), sizeof (procfile), f);
		if (size > 0) {
			if ('\n' == name[size - 1])
				name[size - 1] = '\0';
		}
		fclose(f);
	}
}

void hardening() {
    prctl(PR_SET_DUMPABLE, 0);
    prctl(PR_SET_PTRACER, -1);

    int pid = getppid();
    char name[256] = {0};
    gets_process_name(pid, name);

    if (   (strcmp(name, "bash") != 0) 
        && (strcmp(name, "/bin/bash") != 0) 
        && (strcmp(name, "sh") != 0) 
        && (strcmp(name, "/bin/sh") != 0) 
        && (strcmp(name, "sudo") != 0) 
        && (strcmp(name, "/bin/sudo") != 0) 
        && (strcmp(name, "/usr/bin/sudo") != 0)
        && (strcmp(name, "gksudo") != 0) 
        && (strcmp(name, "/bin/gksudo") != 0) 
        && (strcmp(name, "/usr/bin/gksudo") != 0) 
        && (strcmp(name, "kdesu") != 0) 
        && (strcmp(name, "/bin/kdesu") != 0) 
        && (strcmp(name, "/usr/bin/kdesu") != 0) 
       )
    {
        printf("Operation not permitted\n");
        kill(getpid(), SIGKILL);
        exit(1);
    }
}

#endif /* HARDENING */

#if !TRACEABLE

#define _LINUX_SOURCE_COMPAT
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <unistd.h>

#if !defined(PT_ATTACHEXC) /* New replacement for PT_ATTACH */
   #if !defined(PTRACE_ATTACH) && defined(PT_ATTACH)
       #define PT_ATTACHEXC	PT_ATTACH
   #elif defined(PTRACE_ATTACH)
       #define PT_ATTACHEXC PTRACE_ATTACH
   #endif
#endif

void untraceable(char * argv0)
{
	char proc[80];
	int pid, mine;

	switch(pid = fork()) {
	case  0:
		pid = getppid();
		/* For problematic SunOS ptrace */
#if defined(__FreeBSD__)
		sprintf(proc, "/proc/%d/mem", (int)pid);
#else
		sprintf(proc, "/proc/%d/as",  (int)pid);
#endif
		close(0);
		mine = !open(proc, O_RDWR|O_EXCL);
		if (!mine && errno != EBUSY)
			mine = !ptrace(PT_ATTACHEXC, pid, 0, 0);
		if (mine) {
			kill(pid, SIGCONT);
		} else {
			perror(argv0);
			kill(pid, SIGKILL);
		}
		_exit(mine);
	case -1:
		break;
	default:
		if (pid == waitpid(pid, 0, 0))
			return;
	}
	perror(argv0);
	_exit(1);
}
#endif /* !TRACEABLE */

char * xsh(int argc, char ** argv)
{
	char * scrpt;
	int ret, i, j;
	char ** varg;
	char * me = argv[0];
	if (me == NULL) { me = getenv("_"); }
	if (me == 0) { fprintf(stderr, "E: neither argv[0] nor $_ works."); exit(1); }

	ret = chkenv(argc);
	stte_0();
	 key(pswd, pswd_z);
	arc4(msg1, msg1_z);
	arc4(date, date_z);
	if (date[0] && (atoll(date)<time(NULL)))
		return msg1;
	arc4(shll, shll_z);
	arc4(inlo, inlo_z);
	arc4(xecc, xecc_z);
	arc4(lsto, lsto_z);
	arc4(tst1, tst1_z);
	 key(tst1, tst1_z);
	arc4(chk1, chk1_z);
	if ((chk1_z != tst1_z) || memcmp(tst1, chk1, tst1_z))
		return tst1;
	arc4(msg2, msg2_z);
	if (ret < 0)
		return msg2;
	varg = (char **)calloc(argc + 10, sizeof(char *));
	if (!varg)
		return 0;
	if (ret) {
		arc4(rlax, rlax_z);
		if (!rlax[0] && key_with_file(shll))
			return shll;
		arc4(opts, opts_z);
#if HARDENING
	    arc4_hardrun(text, text_z);
	    exit(0);
       /* Seccomp Sandboxing - Start */
       seccomp_hardening();
#endif
		arc4(text, text_z);
		arc4(tst2, tst2_z);
		 key(tst2, tst2_z);
		arc4(chk2, chk2_z);
		if ((chk2_z != tst2_z) || memcmp(tst2, chk2, tst2_z))
			return tst2;
		/* Prepend hide_z spaces to script text to hide it. */
		scrpt = malloc(hide_z + text_z);
		if (!scrpt)
			return 0;
		memset(scrpt, (int) ' ', hide_z);
		memcpy(&scrpt[hide_z], text, text_z);
	} else {			/* Reexecute */
		if (*xecc) {
			scrpt = malloc(512);
			if (!scrpt)
				return 0;
			sprintf(scrpt, xecc, me);
		} else {
			scrpt = me;
		}
	}
	j = 0;
#if BUSYBOXON
	varg[j++] = "busybox";
	varg[j++] = "sh";
#else
	varg[j++] = argv[0];		/* My own name at execution */
#endif
	if (ret && *opts)
		varg[j++] = opts;	/* Options on 1st line of code */
	if (*inlo)
		varg[j++] = inlo;	/* Option introducing inline code */
	varg[j++] = scrpt;		/* The script itself */
	if (*lsto)
		varg[j++] = lsto;	/* Option meaning last option */
	i = (ret > 1) ? ret : 0;	/* Args numbering correction */
	while (i < argc)
		varg[j++] = argv[i++];	/* Main run-time arguments */
	varg[j] = 0;			/* NULL terminated array */
#if DEBUGEXEC
	debugexec(shll, j, varg);
#endif
	execvp(shll, varg);
	return shll;
}

int main(int argc, char ** argv)
{
#if SETUID
   setuid(0);
#endif
#if DEBUGEXEC
	debugexec("main", argc, argv);
#endif
#if HARDENING
	hardening();
#endif
#if !TRACEABLE
	untraceable(argv[0]);
#endif
	argv[1] = xsh(argc, argv);
	fprintf(stderr, "%s%s%s: %s\n", argv[0],
		errno ? ": " : "",
		errno ? strerror(errno) : "",
		argv[1] ? argv[1] : "<null>"
	);
	return 1;
}
