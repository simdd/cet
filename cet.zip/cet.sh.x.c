#if 0
	shc Version 4.0.1, Generic Shell Script Compiler
	GNU GPL Version 3 Md Jahidul Hamid <jahidulhamid@yahoo.com>

	shc -f cet.sh -o cet 
#endif

static  char data [] = 
#define      xecc_z	15
#define      xecc	((&data[0]))
	"\236\022\367\067\065\132\007\242\054\045\002\057\356\270\354"
#define      opts_z	1
#define      opts	((&data[15]))
	"\173"
#define      text_z	1021
#define      text	((&data[59]))
	"\271\072\234\342\101\370\055\330\237\322\352\333\034\072\005\024"
	"\263\341\104\040\321\171\074\355\334\121\113\316\303\165\367\330"
	"\277\256\334\353\104\360\220\275\025\166\074\033\112\165\233\031"
	"\044\235\235\113\360\057\026\331\107\106\235\223\227\242\364\303"
	"\300\001\134\064\135\363\064\373\207\246\377\241\126\076\123\037"
	"\213\115\357\360\342\216\011\241\161\077\237\213\153\232\140\066"
	"\302\301\160\162\306\322\220\123\156\363\270\352\232\113\110\003"
	"\232\315\223\322\042\206\361\332\221\377\242\322\373\143\057\370"
	"\206\143\265\123\054\106\251\270\336\055\323\301\223\352\374\145"
	"\367\276\056\322\065\333\033\207\100\121\057\046\327\140\321\055"
	"\143\023\020\341\170\222\105\165\112\135\360\122\234\334\264\134"
	"\262\372\040\027\270\025\347\270\201\031\230\116\071\037\304\332"
	"\361\361\046\053\236\105\101\234\375\212\114\373\167\321\044\305"
	"\342\337\065\340\127\055\251\224\031\051\125\341\017\071\235\374"
	"\223\115\025\215\140\055\112\244\015\115\310\030\142\311\217\064"
	"\140\352\251\273\175\317\025\232\016\155\324\031\343\055\375\007"
	"\111\121\142\155\243\062\063\346\217\157\062\316\271\012\367\321"
	"\220\267\020\276\030\002\117\265\145\345\302\211\023\200\046\077"
	"\243\274\221\152\307\026\204\021\345\216\123\163\317\146\044\103"
	"\267\212\267\010\110\261\345\370\346\060\245\200\105\040\026\231"
	"\270\262\144\076\014\362\211\033\364\202\145\166\110\042\272\151"
	"\117\046\366\007\056\320\165\223\350\171\013\037\055\022\047\371"
	"\155\166\126\170\033\035\057\307\244\170\040\200\030\202\012\310"
	"\307\240\335\333\072\274\312\222\050\351\252\263\071\073\043\321"
	"\325\206\323\017\353\133\055\120\144\237\132\174\264\031\063\232"
	"\037\365\160\342\156\367\132\163\172\340\014\007\236\345\340\356"
	"\267\027\154\334\253\212\236\340\034\205\023\154\221\270\124\247"
	"\254\015\303\122\305\116\365\043\144\166\217\374\035\063\350\201"
	"\244\020\044\247\002\345\137\170\022\321\362\033\266\135\172\313"
	"\075\240\034\046\016\313\265\221\052\206\140\306\252\075\165\017"
	"\060\071\032\122\044\061\160\154\353\140\225\033\336\143\366\154"
	"\325\230\261\000\074\126\146\173\053\050\122\304\060\067\376\063"
	"\004\356\032\213\150\243\352\240\204\065\256\246\262\015\226\264"
	"\016\123\251\351\144\124\267\331\334\067\246\102\063\071\176\057"
	"\035\060\172\242\105\075\255\372\167\220\367\150\125\367\171\120"
	"\354\141\214\004\025\202\150\354\325\143\220\202\012\027\157\171"
	"\321\127\332\203\347\100\202\224\215\370\103\323\340\344\001\046"
	"\116\254\236\116\037\111\367\267\314\335\072\361\070\065\335\364"
	"\132\204\376\010\271\311\311\263\323\157\364\073\041\337\212\301"
	"\352\102\223\373\274\120\161\111\364\010\247\033\312\340\334\323"
	"\223\134\342\150\073\045\206\360\326\273\232\153\035\205\071\267"
	"\031\167\163\037\004\222\362\156\153\311\224\126\221\072\264\122"
	"\107\332\343\007\246\154\303\377\200\202\177\127\065\141\276\254"
	"\106\072\372\352\352\377\306\123\300\075\315\113\326\115\120\052"
	"\227\370\332\114\304\220\352\037\202\040\171\213\211\336\045\162"
	"\174\370\002\250\341\260\107\037\166\127\213\021\233\047\157\021"
	"\142\166\115\175\003\157\137\062\111\122\002\273\075\366\052\134"
	"\122\177\106\076\323\104\335\072\225\026\120\302\360\010\017\371"
	"\131\202\011\232\215\071\046\171\165\013\056\147\077\313\277\267"
	"\275\221\214\325\356\302\374\065\152\237\072\220\244\233\326\261"
	"\330\075\063\064\346\102\246\071\353\156\267\320\042\012\131\036"
	"\215\136\050\256\140\245\203\111\217\043\371\066\156\217\252\016"
	"\062\062\266\117\046\071\253\175\342\306\116\352\267\117\212\375"
	"\230\266\224\126\153\366\203\240\032\202\255\340\310\320\170\211"
	"\305\176\237\307\274\020\160\265\160\100\371\311\041\247\004\220"
	"\004\236\136\114\236\213\303\067\233\006\143\372\014\074\007\021"
	"\326\017\232\064\041\206\067\360\005\305\350\035\240\057\252\374"
	"\044\307\174\273\206\377\006\352\372\143\062\041\103\212\326\232"
	"\153\134\325\124\255\327\200\031\107\157\377\260\227\331\234\274"
	"\272\040\200\142\133\037\251\343\373\322\360\351\363\024\240\307"
	"\246\311\012\323\174\075\066\256\230\333\172\276\251\063\131\011"
	"\115\244\310\360\256\262\371\011\130\155\304\237\342\070\177\332"
	"\301\151\155\046\146\154\110\206\241\053\041\345\132\204\237\047"
	"\216\007\067\106\106\013\130\357\244\302\127\130\051\113\164\124"
	"\273\247\376\104\065\275\121\331\254\112\147\234\341\225\301\146"
	"\357\074\012\265\246\204\317\200\144\232\317\111\031\146\302\022"
	"\047\106\377\206\270\121\127\324\365\105\122\334\237\104\267\330"
	"\153\133\106\002\251\153\071\166\345\070\102\352\136\242\141\117"
	"\170\143\102\275\046\130\114\350\032\350\174\252\121\022\107\063"
#define      tst2_z	19
#define      tst2	((&data[1123]))
	"\264\314\054\273\366\064\242\144\113\135\322\201\321\216\074\140"
	"\361\276\056\242\244\343\017\221\323\144"
#define      tst1_z	22
#define      tst1	((&data[1147]))
	"\137\241\204\206\242\343\150\171\301\271\073\372\210\267\314\371"
	"\272\175\075\064\263\130\201\332\346\366\062"
#define      msg1_z	65
#define      msg1	((&data[1178]))
	"\122\104\145\304\307\317\076\076\272\334\356\231\074\101\314\372"
	"\252\161\240\112\240\155\241\213\213\061\020\077\163\077\324\336"
	"\223\234\241\032\230\107\224\267\154\277\376\250\055\140\050\131"
	"\101\105\232\020\131\267\166\110\061\066\310\131\313\364\340\003"
	"\363\167\217\200\245\151\255\206\101\170\335\107"
#define      lsto_z	1
#define      lsto	((&data[1249]))
	"\171"
#define      pswd_z	256
#define      pswd	((&data[1311]))
	"\001\177\151\145\215\267\275\333\231\276\213\335\342\073\205\016"
	"\262\366\300\170\134\110\337\057\315\154\132\036\205\316\114\115"
	"\355\115\115\235\354\261\233\017\315\324\100\271\171\045\162\345"
	"\162\217\177\217\362\252\265\251\200\134\267\167\352\220\016\104"
	"\073\311\174\131\011\113\225\303\145\375\233\140\370\132\141\274"
	"\356\047\276\276\121\324\014\162\102\165\264\127\002\060\371\061"
	"\303\147\354\244\330\244\375\343\310\077\241\147\166\132\350\027"
	"\337\376\170\305\364\131\037\037\315\356\037\356\260\205\167\223"
	"\001\210\357\062\014\243\236\031\276\144\341\277\316\177\337\103"
	"\374\022\122\375\025\127\024\112\031\156\023\163\260\227\327\027"
	"\311\005\131\343\266\155\027\045\337\066\351\051\314\270\242\061"
	"\153\240\027\054\261\312\150\070\254\032\153\140\027\142\177\224"
	"\375\356\026\131\026\150\123\166\344\262\331\374\345\261\231\015"
	"\255\326\116\326\303\025\247\311\323\347\222\334\250\311\073\305"
	"\225\215\116\362\040\105\255\037\274\342\177\125\373\177\170\222"
	"\144\260\276\145\117\027\037\354\262\031\335\175\002\354\206\167"
	"\262\367\273\250\220\053\365\205\050\127\321\340\077\214\227\314"
	"\037\126\114\332\231\043\272\337\056\316\301\027\024\176\065\052"
	"\031\232\037\114\115\244\126\372\372\270\354\326\157\025\203\044"
	"\003\053\350\171\373\045\222\352\322\140\051\375\202\130\244\036"
	"\214\231\325\036\247\264\015\350\067\335\053\310"
#define      date_z	1
#define      date	((&data[1582]))
	"\072"
#define      msg2_z	19
#define      msg2	((&data[1587]))
	"\327\207\206\233\331\253\302\113\301\314\031\140\236\170\002\216"
	"\131\260\052\115\040\331\032\105\274\045"
#define      chk1_z	22
#define      chk1	((&data[1610]))
	"\130\056\373\015\061\311\213\263\254\000\276\152\076\076\166\325"
	"\035\167\212\053\146\345\117\016\325\156\006\223"
#define      shll_z	10
#define      shll	((&data[1639]))
	"\101\273\276\214\263\312\121\030\005\033\370\345"
#define      chk2_z	19
#define      chk2	((&data[1651]))
	"\135\006\171\026\325\370\306\276\361\013\265\136\253\332\015\030"
	"\323\105\030\044\070\117\177\043\213"
#define      rlax_z	1
#define      rlax	((&data[1674]))
	"\017"
#define      inlo_z	3
#define      inlo	((&data[1675]))
	"\076\170\316"/* End of data[] */;
#define      hide_z	4096
#define SETUID 0	/* Define as 1 to call setuid(0) at start of script */
#define DEBUGEXEC	0	/* Define as 1 to debug execvp calls */
#define TRACEABLE	1	/* Define as 1 to enable ptrace the executable */
#define HARDENING	0	/* Define as 1 to disable ptrace/dump the executable */
#define HARDENINGSP	0	/* Define as 1 to disable bash child process */
#define BUSYBOXON	0	/* Define as 1 to enable work with busybox */

/* rtc.c */

#include <sys/stat.h>
#include <sys/types.h>

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

/* 'Alleged RC4' */

static unsigned char stte[256], indx, jndx, kndx;

/*
 * Reset arc4 stte. 
 */
void stte_0(void)
{
	indx = jndx = kndx = 0;
	do {
		stte[indx] = indx;
	} while (++indx);
}

/*
 * Set key. Can be used more than once. 
 */
void key(void * str, int len)
{
	unsigned char tmp, * ptr = (unsigned char *)str;
	while (len > 0) {
		do {
			tmp = stte[indx];
			kndx += tmp;
			kndx += ptr[(int)indx % len];
			stte[indx] = stte[kndx];
			stte[kndx] = tmp;
		} while (++indx);
		ptr += 256;
		len -= 256;
	}
}

/*
 * Crypt data. 
 */
void arc4(void * str, int len)
{
	unsigned char tmp, * ptr = (unsigned char *)str;
	while (len > 0) {
		indx++;
		tmp = stte[indx];
		jndx += tmp;
		stte[indx] = stte[jndx];
		stte[jndx] = tmp;
		tmp += stte[indx];
		*ptr ^= stte[tmp];
		ptr++;
		len--;
	}
}

/* End of ARC4 */

#if HARDENING

#include <sys/ptrace.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/prctl.h>
#define PR_SET_PTRACER 0x59616d61

/* Seccomp Sandboxing Init */
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/prctl.h>
#include <sys/syscall.h>
#include <sys/socket.h>

#include <linux/filter.h>
#include <linux/seccomp.h>
#include <linux/audit.h>

#define ArchField offsetof(struct seccomp_data, arch)

#define Allow(syscall) \
    BPF_JUMP(BPF_JMP+BPF_JEQ+BPF_K, SYS_##syscall, 0, 1), \
    BPF_STMT(BPF_RET+BPF_K, SECCOMP_RET_ALLOW)

struct sock_filter filter[] = {
    /* validate arch */
    BPF_STMT(BPF_LD+BPF_W+BPF_ABS, ArchField),
    BPF_JUMP( BPF_JMP+BPF_JEQ+BPF_K, AUDIT_ARCH_X86_64, 1, 0),
    BPF_STMT(BPF_RET+BPF_K, SECCOMP_RET_KILL),

    /* load syscall */
    BPF_STMT(BPF_LD+BPF_W+BPF_ABS, offsetof(struct seccomp_data, nr)),

    /* list of allowed syscalls */
    Allow(exit_group),  /* exits a processs */
    Allow(brk),         /* for malloc(), inside libc */
    Allow(mmap),        /* also for malloc() */
    Allow(munmap),      /* for free(), inside libc */

    /* and if we don't match above, die */
    BPF_STMT(BPF_RET+BPF_K, SECCOMP_RET_KILL),
};
struct sock_fprog filterprog = {
    .len = sizeof(filter)/sizeof(filter[0]),
    .filter = filter
};

/* Seccomp Sandboxing - Set up the restricted environment */
void seccomp_hardening() {
    if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0)) {
        perror("Could not start seccomp:");
        exit(1);
    }
    if (prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &filterprog) == -1) {
        perror("Could not start seccomp:");
        exit(1);
    }
} 
/* End Seccomp Sandboxing Init */

void arc4_hardrun(void * str, int len) {
    //Decode locally
    char tmp2[len];
    memcpy(tmp2, str, len);

	unsigned char tmp, * ptr = (unsigned char *)tmp2;

    int lentmp = len;

#if HARDENINGSP
    //Start tracing to protect from dump & trace
    if (ptrace(PTRACE_TRACEME, 0, 0, 0) < 0) {
        printf("Operation not permitted\n");
        kill(getpid(), SIGKILL);
        exit(1);
    }

    //Decode Bash
    while (len > 0) {
        indx++;
        tmp = stte[indx];
        jndx += tmp;
        stte[indx] = stte[jndx];
        stte[jndx] = tmp;
        tmp += stte[indx];
        *ptr ^= stte[tmp];
        ptr++;
        len--;
    }

    //Exec bash script
    system(tmp2);

    //Empty script variable
    memcpy(tmp2, str, lentmp);

    //Sinal to detach ptrace
    ptrace(PTRACE_DETACH, 0, 0, 0);
    exit(0);

    /* Seccomp Sandboxing - Start */
    seccomp_hardening();

    exit(0);
#endif /* HARDENINGSP Exit here anyway*/

    int pid, status;
    pid = fork();

    if(pid==0) {

        //Start tracing to protect from dump & trace
        if (ptrace(PTRACE_TRACEME, 0, 0, 0) < 0) {
            printf("Operation not permitted\n");
            kill(getpid(), SIGKILL);
            _exit(1);
        }

        //Decode Bash
        while (len > 0) {
            indx++;
            tmp = stte[indx];
            jndx += tmp;
            stte[indx] = stte[jndx];
            stte[jndx] = tmp;
            tmp += stte[indx];
            *ptr ^= stte[tmp];
            ptr++;
            len--;
        }

        //Exec bash script
        system(tmp2);

        //Empty script variable
        memcpy(tmp2, str, lentmp);

        //Sinal to detach ptrace
        ptrace(PTRACE_DETACH, 0, 0, 0);
        exit(0);
    }
    else {
        wait(&status);
    }

    /* Seccomp Sandboxing - Start */
    seccomp_hardening();

    exit(0);
} 
#endif /* HARDENING */

/*
 * Key with file invariants. 
 */
int key_with_file(char * file)
{
	struct stat statf[1];
	struct stat control[1];

	if (stat(file, statf) < 0)
		return -1;

	/* Turn on stable fields */
	memset(control, 0, sizeof(control));
	control->st_ino = statf->st_ino;
	control->st_dev = statf->st_dev;
	control->st_rdev = statf->st_rdev;
	control->st_uid = statf->st_uid;
	control->st_gid = statf->st_gid;
	control->st_size = statf->st_size;
	control->st_mtime = statf->st_mtime;
	control->st_ctime = statf->st_ctime;
	key(control, sizeof(control));
	return 0;
}

#if DEBUGEXEC
void debugexec(char * sh11, int argc, char ** argv)
{
	int i;
	fprintf(stderr, "shll=%s\n", sh11 ? sh11 : "<null>");
	fprintf(stderr, "argc=%d\n", argc);
	if (!argv) {
		fprintf(stderr, "argv=<null>\n");
	} else { 
		for (i = 0; i <= argc ; i++)
			fprintf(stderr, "argv[%d]=%.60s\n", i, argv[i] ? argv[i] : "<null>");
	}
}
#endif /* DEBUGEXEC */

void rmarg(char ** argv, char * arg)
{
	for (; argv && *argv && *argv != arg; argv++);
	for (; argv && *argv; argv++)
		*argv = argv[1];
}

void chkenv_end(void);

int chkenv(int argc)
{
	char buff[512];
	unsigned long mask, m;
	int l, a, c;
	char * string;
	extern char ** environ;

	mask = (unsigned long)getpid();
	stte_0();
	 key(&chkenv, (void*)&chkenv_end - (void*)&chkenv);
	 key(&data, sizeof(data));
	 key(&mask, sizeof(mask));
	arc4(&mask, sizeof(mask));
	sprintf(buff, "x%lx", mask);
	string = getenv(buff);
#if DEBUGEXEC
	fprintf(stderr, "getenv(%s)=%s\n", buff, string ? string : "<null>");
#endif
	l = strlen(buff);
	if (!string) {
		/* 1st */
		sprintf(&buff[l], "=%lu %d", mask, argc);
		putenv(strdup(buff));
		return 0;
	}
	c = sscanf(string, "%lu %d%c", &m, &a, buff);
	if (c == 2 && m == mask) {
		/* 3rd */
		rmarg(environ, &string[-l - 1]);
		return 1 + (argc - a);
	}
	return -1;
}

void chkenv_end(void){}

#if HARDENING

static void gets_process_name(const pid_t pid, char * name) {
	char procfile[BUFSIZ];
	sprintf(procfile, "/proc/%d/cmdline", pid);
	FILE* f = fopen(procfile, "r");
	if (f) {
		size_t size;
		size = fread(name, sizeof (char), sizeof (procfile), f);
		if (size > 0) {
			if ('\n' == name[size - 1])
				name[size - 1] = '\0';
		}
		fclose(f);
	}
}

void hardening() {
    prctl(PR_SET_DUMPABLE, 0);
    prctl(PR_SET_PTRACER, -1);

    int pid = getppid();
    char name[256] = {0};
    gets_process_name(pid, name);

    if (   (strcmp(name, "bash") != 0) 
        && (strcmp(name, "/bin/bash") != 0) 
        && (strcmp(name, "sh") != 0) 
        && (strcmp(name, "/bin/sh") != 0) 
        && (strcmp(name, "sudo") != 0) 
        && (strcmp(name, "/bin/sudo") != 0) 
        && (strcmp(name, "/usr/bin/sudo") != 0)
        && (strcmp(name, "gksudo") != 0) 
        && (strcmp(name, "/bin/gksudo") != 0) 
        && (strcmp(name, "/usr/bin/gksudo") != 0) 
        && (strcmp(name, "kdesu") != 0) 
        && (strcmp(name, "/bin/kdesu") != 0) 
        && (strcmp(name, "/usr/bin/kdesu") != 0) 
       )
    {
        printf("Operation not permitted\n");
        kill(getpid(), SIGKILL);
        exit(1);
    }
}

#endif /* HARDENING */

#if !TRACEABLE

#define _LINUX_SOURCE_COMPAT
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <unistd.h>

#if !defined(PT_ATTACHEXC) /* New replacement for PT_ATTACH */
   #if !defined(PTRACE_ATTACH) && defined(PT_ATTACH)
       #define PT_ATTACHEXC	PT_ATTACH
   #elif defined(PTRACE_ATTACH)
       #define PT_ATTACHEXC PTRACE_ATTACH
   #endif
#endif

void untraceable(char * argv0)
{
	char proc[80];
	int pid, mine;

	switch(pid = fork()) {
	case  0:
		pid = getppid();
		/* For problematic SunOS ptrace */
#if defined(__FreeBSD__)
		sprintf(proc, "/proc/%d/mem", (int)pid);
#else
		sprintf(proc, "/proc/%d/as",  (int)pid);
#endif
		close(0);
		mine = !open(proc, O_RDWR|O_EXCL);
		if (!mine && errno != EBUSY)
			mine = !ptrace(PT_ATTACHEXC, pid, 0, 0);
		if (mine) {
			kill(pid, SIGCONT);
		} else {
			perror(argv0);
			kill(pid, SIGKILL);
		}
		_exit(mine);
	case -1:
		break;
	default:
		if (pid == waitpid(pid, 0, 0))
			return;
	}
	perror(argv0);
	_exit(1);
}
#endif /* !TRACEABLE */

char * xsh(int argc, char ** argv)
{
	char * scrpt;
	int ret, i, j;
	char ** varg;
	char * me = argv[0];
	if (me == NULL) { me = getenv("_"); }
	if (me == 0) { fprintf(stderr, "E: neither argv[0] nor $_ works."); exit(1); }

	ret = chkenv(argc);
	stte_0();
	 key(pswd, pswd_z);
	arc4(msg1, msg1_z);
	arc4(date, date_z);
	if (date[0] && (atoll(date)<time(NULL)))
		return msg1;
	arc4(shll, shll_z);
	arc4(inlo, inlo_z);
	arc4(xecc, xecc_z);
	arc4(lsto, lsto_z);
	arc4(tst1, tst1_z);
	 key(tst1, tst1_z);
	arc4(chk1, chk1_z);
	if ((chk1_z != tst1_z) || memcmp(tst1, chk1, tst1_z))
		return tst1;
	arc4(msg2, msg2_z);
	if (ret < 0)
		return msg2;
	varg = (char **)calloc(argc + 10, sizeof(char *));
	if (!varg)
		return 0;
	if (ret) {
		arc4(rlax, rlax_z);
		if (!rlax[0] && key_with_file(shll))
			return shll;
		arc4(opts, opts_z);
#if HARDENING
	    arc4_hardrun(text, text_z);
	    exit(0);
       /* Seccomp Sandboxing - Start */
       seccomp_hardening();
#endif
		arc4(text, text_z);
		arc4(tst2, tst2_z);
		 key(tst2, tst2_z);
		arc4(chk2, chk2_z);
		if ((chk2_z != tst2_z) || memcmp(tst2, chk2, tst2_z))
			return tst2;
		/* Prepend hide_z spaces to script text to hide it. */
		scrpt = malloc(hide_z + text_z);
		if (!scrpt)
			return 0;
		memset(scrpt, (int) ' ', hide_z);
		memcpy(&scrpt[hide_z], text, text_z);
	} else {			/* Reexecute */
		if (*xecc) {
			scrpt = malloc(512);
			if (!scrpt)
				return 0;
			sprintf(scrpt, xecc, me);
		} else {
			scrpt = me;
		}
	}
	j = 0;
#if BUSYBOXON
	varg[j++] = "busybox";
	varg[j++] = "sh";
#else
	varg[j++] = argv[0];		/* My own name at execution */
#endif
	if (ret && *opts)
		varg[j++] = opts;	/* Options on 1st line of code */
	if (*inlo)
		varg[j++] = inlo;	/* Option introducing inline code */
	varg[j++] = scrpt;		/* The script itself */
	if (*lsto)
		varg[j++] = lsto;	/* Option meaning last option */
	i = (ret > 1) ? ret : 0;	/* Args numbering correction */
	while (i < argc)
		varg[j++] = argv[i++];	/* Main run-time arguments */
	varg[j] = 0;			/* NULL terminated array */
#if DEBUGEXEC
	debugexec(shll, j, varg);
#endif
	execvp(shll, varg);
	return shll;
}

int main(int argc, char ** argv)
{
#if SETUID
   setuid(0);
#endif
#if DEBUGEXEC
	debugexec("main", argc, argv);
#endif
#if HARDENING
	hardening();
#endif
#if !TRACEABLE
	untraceable(argv[0]);
#endif
	argv[1] = xsh(argc, argv);
	fprintf(stderr, "%s%s%s: %s\n", argv[0],
		errno ? ": " : "",
		errno ? strerror(errno) : "",
		argv[1] ? argv[1] : "<null>"
	);
	return 1;
}
